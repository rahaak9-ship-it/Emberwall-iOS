class_name GameData
extends RefCounted

# Logical stage. Width expands on wider phones; height stays 480 and is
# centered vertically on iPads.
const STAGE_HEIGHT := 480.0
const GROUND_Y := 414.0
const WALL_X := 150.0
const WALL_TOP := 294.0
const ARCHER_FEET := Vector2(132.0, 315.0)
const BOW_POS := Vector2(160.0, 294.0)

const GRAVITY := 820.0
const MIN_SHOT_SPEED := 420.0
const MAX_SHOT_SPEED := 930.0
const MAX_PULL := 148.0
const MIN_PULL := 13.0
const BASE_DAMAGE := 22.0
const BASE_COOLDOWN := 0.60

const WALL_MAX := 100.0
const TOTAL_WAVES := 12
const START_COINS := 20

# Palette
const INK := Color("#070b1b")
const SKY_MID := Color("#121a38")
const SKY_LOW := Color("#25305a")
const BONE := Color("#f3ead9")
const BONE_DIM := Color("#b9b6c9")
const EMBER := Color("#ff7a2f")
const EMBER_DEEP := Color("#cf4520")
const GOLD := Color("#ffc857")
const TEAL := Color("#55c7b4")
const BLOOD := Color("#e5484d")
const PANEL := Color("#11182f")
const PANEL_LIGHT := Color("#1b2444")
const NIGHT := Color("#0b1026")
const STONE := Color("#2c3557")
const STONE_DARK := Color("#1c2442")
const MOON := Color("#f5e7c6")

static func stage_offset_y(viewport_height: float) -> float:
	return maxf(0.0, (viewport_height - STAGE_HEIGHT) * 0.5)

static func segment_circle_hit(a: Vector2, b: Vector2, center: Vector2, radius: float) -> bool:
	var ab := b - a
	var len_sq := ab.length_squared()
	if len_sq < 0.0001:
		return a.distance_squared_to(center) <= radius * radius
	var t := clampf((center - a).dot(ab) / len_sq, 0.0, 1.0)
	return (a + ab * t).distance_squared_to(center) <= radius * radius

static func closest_on_segment(a: Vector2, b: Vector2, p: Vector2) -> Vector2:
	var ab := b - a
	var len_sq := ab.length_squared()
	if len_sq < 0.0001:
		return a
	var t := clampf((p - a).dot(ab) / len_sq, 0.0, 1.0)
	return a + ab * t

static func format_number(value: int) -> String:
	var s := str(maxi(value, 0))
	var out := ""
	var count := 0
	for i in range(s.length() - 1, -1, -1):
		out = s[i] + out
		count += 1
		if count % 3 == 0 and i > 0:
			out = "," + out
	return out
