class_name GameUI
extends CanvasLayer

var main: Node
var theme: Theme
var font_base: FontFile
var font_body: FontVariation
var font_bold: FontVariation
var font_display: FontVariation

var root: Control
var vignette: Vignette
var hud: Control
var safe_margin: MarginContainer
var menu_layer: Control
var tutorial_layer: Control
var shop_layer: Control
var pause_layer: Control
var result_layer: Control

var menu_title: Label
var menu_eyebrow: Label
var menu_best: Label
var night_label: Label
var sound_button: Button
var language_button: Button
var play_button: Button
var how_button: Button

var wall_value: Label
var wall_bar: ProgressBar
var wave_num: Label
var wave_total: Label
var coin_value: Label
var score_value: Label
var boss_box: Control
var boss_bar: ProgressBar
var hint_panel: Control
var banner_panel: PanelContainer
var banner_kicker: Label
var banner_title: Label
var banner_sub: Label
var banner_tween: Tween

var tutorial_art: TutorialArt
var tutorial_page_title: Label
var tutorial_body: Label
var tutorial_back: Button
var tutorial_next: Button
var tutorial_dots: Array = []

var shop_cards: Dictionary = {}
var shop_coins_value: Label
var shop_next_info: Label
var shop_next_button: Button

var result_title: Label
var result_sub: Label
var result_dim: ColorRect
var result_wave_value: Label
var result_kills_value: Label
var result_score_value: Label
var result_best_value: Label
var result_new_best: Label
var result_again_button: Button
var result_menu_button: Button
var result_victory := false

var static_labels: Array = []
var static_buttons: Array = []
var low_wall_style := false
var fill_normal: StyleBoxFlat
var fill_low: StyleBoxFlat
var fill_boss: StyleBoxFlat

func _ready() -> void:
	layer = 20
	_build_fonts()
	_build_theme()
	_build_root()
	_build_menu()
	_build_hud()
	_build_banner()
	_build_tutorial()
	_build_shop()
	_build_pause()
	_build_result()
	apply_safe_area()
	get_viewport().size_changed.connect(apply_safe_area)
	set_process(true)

func _build_fonts() -> void:
	font_base = load("res://assets/fonts/NotoSansArabic-Variable.ttf") as FontFile
	if font_base == null:
		font_base = ThemeDB.fallback_font as FontFile
	font_body = FontVariation.new()
	font_body.base_font = font_base
	font_body.variation_opentype = {"wght": 500}
	font_bold = FontVariation.new()
	font_bold.base_font = font_base
	font_bold.variation_opentype = {"wght": 750}
	font_display = FontVariation.new()
	font_display.base_font = font_base
	font_display.variation_opentype = {"wght": 900}

func _build_theme() -> void:
	theme = Theme.new()
	theme.default_font = font_body
	theme.default_font_size = 15
	theme.set_color("font_color", "Label", GameData.BONE)
	theme.set_color("font_color", "Button", GameData.BONE)
	theme.set_color("font_hover_color", "Button", Color("#ffe3ae"))
	theme.set_color("font_pressed_color", "Button", Color("#1a0d07"))
	theme.set_color("font_disabled_color", "Button", Color(0.6, 0.58, 0.66, 0.55))

	var panel := _stylebox(Color(0.065, 0.095, 0.19, 0.97), Color(1.0, 0.78, 0.34, 0.23), 12, 1)
	panel.shadow_color = Color(0, 0, 0, 0.45)
	panel.shadow_size = 18
	theme.set_stylebox("panel", "PanelContainer", panel)
	theme.set_stylebox("panel", "Panel", panel)

	var bg := StyleBoxFlat.new()
	bg.bg_color = Color(0.02, 0.03, 0.08, 0.65)
	bg.corner_radius_top_left = 4
	bg.corner_radius_top_right = 4
	bg.corner_radius_bottom_left = 4
	bg.corner_radius_bottom_right = 4
	theme.set_stylebox("background", "ProgressBar", bg)
	fill_normal = StyleBoxFlat.new()
	fill_normal.bg_color = Color("#ff8b36")
	fill_normal.corner_radius_top_left = 4
	fill_normal.corner_radius_top_right = 4
	fill_normal.corner_radius_bottom_left = 4
	fill_normal.corner_radius_bottom_right = 4
	fill_low = StyleBoxFlat.new()
	fill_low.bg_color = Color("#e5484d")
	fill_low.corner_radius_top_left = 4
	fill_low.corner_radius_top_right = 4
	fill_low.corner_radius_bottom_left = 4
	fill_low.corner_radius_bottom_right = 4
	fill_boss = StyleBoxFlat.new()
	fill_boss.bg_color = Color("#d9572a")
	fill_boss.corner_radius_top_left = 4
	fill_boss.corner_radius_top_right = 4
	fill_boss.corner_radius_bottom_left = 4
	fill_boss.corner_radius_bottom_right = 4
	theme.set_stylebox("fill", "ProgressBar", fill_normal)
	theme.set_stylebox("focus", "ProgressBar", StyleBoxEmpty.new())

func _build_root() -> void:
	root = Control.new()
	root.name = "UIRoot"
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.theme = theme
	add_child(root)

	vignette = Vignette.new()
	vignette.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	vignette.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(vignette)

func _build_menu() -> void:
	menu_layer = _full_control()
	menu_layer.name = "Menu"
	root.add_child(menu_layer)

	var dim := ColorRect.new()
	dim.color = Color(0.02, 0.03, 0.08, 0.18)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	menu_layer.add_child(dim)

	night_label = _raw_label("NIGHT 01 / 12", 10, Color(0.55, 0.57, 0.67), HORIZONTAL_ALIGNMENT_LEFT)
	night_label.add_theme_color_override("font_color", Color(0.55, 0.57, 0.67))
	night_label.position = Vector2(76, 18)
	night_label.size = Vector2(220, 18)
	menu_layer.add_child(night_label)

	menu_eyebrow = _raw_label("EMBERWALL", 14, GameData.GOLD, HORIZONTAL_ALIGNMENT_CENTER)

	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	menu_layer.add_child(center)

	var box := VBoxContainer.new()
	box.custom_minimum_size = Vector2(420, 0)
	box.alignment = BoxContainer.ALIGNMENT_CENTER
	box.add_theme_constant_override("separation", 7)
	box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	center.add_child(box)

	menu_eyebrow = _raw_label("EMBERWALL", 14, GameData.GOLD, HORIZONTAL_ALIGNMENT_CENTER)
	menu_eyebrow.add_theme_font_override("font", font_bold)
	menu_eyebrow.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	box.add_child(menu_eyebrow)

	menu_title = _raw_label(I18n.t(main.language if main else "ar", "title"), 64, GameData.BONE, HORIZONTAL_ALIGNMENT_CENTER)
	menu_title.add_theme_font_override("font", font_display)
	menu_title.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.55))
	menu_title.add_theme_constant_override("shadow_offset_x", 0)
	menu_title.add_theme_constant_override("shadow_offset_y", 5)
	menu_title.add_theme_constant_override("shadow_outline_size", 0)
	menu_title.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	box.add_child(menu_title)

	var sub := _static_label("subtitle", 16, Color("#cdbfa9"), HORIZONTAL_ALIGNMENT_CENTER)
	sub.add_theme_font_override("font", font_body)
	sub.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	box.add_child(sub)

	var rule_wrap := CenterContainer.new()
	rule_wrap.custom_minimum_size = Vector2(0, 18)
	rule_wrap.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	rule_wrap.mouse_filter = Control.MOUSE_FILTER_IGNORE
	box.add_child(rule_wrap)
	var rule := ColorRect.new()
	rule.color = Color(1.0, 0.56, 0.22, 0.85)
	rule.custom_minimum_size = Vector2(128, 2)
	rule.mouse_filter = Control.MOUSE_FILTER_IGNORE
	rule_wrap.add_child(rule)

	menu_best = _raw_label("", 13, Color("#b8b3c4"), HORIZONTAL_ALIGNMENT_CENTER)
	menu_best.add_theme_font_override("font", font_body)
	menu_best.custom_minimum_size = Vector2(420, 22)
	menu_best.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	box.add_child(menu_best)

	var spacer := Control.new()
	spacer.custom_minimum_size = Vector2(1, 5)
	box.add_child(spacer)

	var bottom_space := Control.new()
	bottom_space.custom_minimum_size = Vector2(1, 12)
	box.add_child(bottom_space)

	play_button = _button("play", true, 316, 56)
	play_button.add_theme_font_size_override("font_size", 19)
	play_button.pressed.connect(func(): main.play_pressed())
	box.add_child(play_button)

	how_button = _button("how", false, 316, 44)
	how_button.add_theme_font_size_override("font_size", 15)
	how_button.pressed.connect(func(): main.show_tutorial(false))
	box.add_child(how_button)

	var chips := HBoxContainer.new()
	chips.add_theme_constant_override("separation", 9)
	chips.alignment = BoxContainer.ALIGNMENT_CENTER
	chips.custom_minimum_size = Vector2(316, 38)
	chips.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	chips.mouse_filter = Control.MOUSE_FILTER_IGNORE
	box.add_child(chips)

	language_button = _button("language", false, 152, 36)
	language_button.add_theme_font_size_override("font_size", 12)
	language_button.pressed.connect(func(): main.toggle_language())
	chips.add_child(language_button)

	sound_button = _button("sound_on", false, 156, 36)
	sound_button.add_theme_font_size_override("font_size", 12)
	sound_button.pressed.connect(func(): main.toggle_sound())
	chips.add_child(sound_button)

	# The footer is intentionally omitted here to keep the menu clear on a 430pt
	# landscape screen; the wordmark above carries the identity.

func _build_hud() -> void:
	hud = _full_control()
	hud.name = "HUD"
	hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(hud)

	var top_bg := ColorRect.new()
	top_bg.color = Color(0.02, 0.03, 0.075, 0.78)
	top_bg.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	top_bg.offset_bottom = 76
	top_bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(top_bg)

	safe_margin = MarginContainer.new()
	safe_margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	safe_margin.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(safe_margin)

	var top := HBoxContainer.new()
	top.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	top.offset_bottom = 64
	top.custom_minimum_size = Vector2(0, 64)
	top.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	top.add_theme_constant_override("separation", 16)
	top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	safe_margin.add_child(top)

	var left := VBoxContainer.new()
	left.custom_minimum_size = Vector2(196, 0)
	left.add_theme_constant_override("separation", 4)
	left.mouse_filter = Control.MOUSE_FILTER_IGNORE
	top.add_child(left)

	var wall_cap := HBoxContainer.new()
	wall_cap.mouse_filter = Control.MOUSE_FILTER_IGNORE
	left.add_child(wall_cap)
	var wall_name := _static_label("wall", 10, Color(0.72, 0.73, 0.80), HORIZONTAL_ALIGNMENT_LEFT)
	wall_name.add_theme_font_size_override("font_size", 10)
	wall_name.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	wall_cap.add_child(wall_name)
	wall_value = _raw_label("100%", 12, GameData.BONE, HORIZONTAL_ALIGNMENT_RIGHT)
	wall_value.add_theme_font_override("font", font_bold)
	wall_cap.add_child(wall_value)

	wall_bar = ProgressBar.new()
	wall_bar.custom_minimum_size = Vector2(180, 9)
	wall_bar.max_value = 100.0
	wall_bar.value = 100.0
	wall_bar.show_percentage = false
	wall_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	left.add_child(wall_bar)

	var center := VBoxContainer.new()
	center.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	center.alignment = BoxContainer.ALIGNMENT_BEGIN
	center.add_theme_constant_override("separation", 0)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	top.add_child(center)

	var wave_cap := _static_label("wave", 10, Color(0.72, 0.73, 0.80), HORIZONTAL_ALIGNMENT_CENTER)
	wave_cap.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	center.add_child(wave_cap)

	var wave_row := HBoxContainer.new()
	wave_row.alignment = BoxContainer.ALIGNMENT_CENTER
	wave_row.add_theme_constant_override("separation", 5)
	wave_row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	center.add_child(wave_row)
	wave_num = _raw_label("04", 24, GameData.BONE, HORIZONTAL_ALIGNMENT_RIGHT)
	wave_num.add_theme_font_override("font", font_bold)
	wave_row.add_child(wave_num)
	var slash := _raw_label("/", 15, Color(0.65, 0.67, 0.75), HORIZONTAL_ALIGNMENT_CENTER)
	wave_row.add_child(slash)
	wave_total = _raw_label("12", 15, Color(0.65, 0.67, 0.75), HORIZONTAL_ALIGNMENT_LEFT)
	wave_row.add_child(wave_total)

	boss_box = VBoxContainer.new()
	boss_box.visible = false
	boss_box.add_theme_constant_override("separation", 3)
	boss_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	center.add_child(boss_box)
	var boss_name := _static_label("boss", 8, Color("#e68282"), HORIZONTAL_ALIGNMENT_CENTER)
	boss_name.add_theme_font_override("font", font_bold)
	boss_box.add_child(boss_name)
	boss_bar = ProgressBar.new()
	boss_bar.custom_minimum_size = Vector2(220, 6)
	boss_bar.max_value = 100.0
	boss_bar.show_percentage = false
	boss_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	boss_bar.add_theme_stylebox_override("fill", fill_boss)
	boss_box.add_child(boss_bar)

	var right := HBoxContainer.new()
	right.custom_minimum_size = Vector2(250, 0)
	right.alignment = BoxContainer.ALIGNMENT_END
	right.add_theme_constant_override("separation", 17)
	right.mouse_filter = Control.MOUSE_FILTER_IGNORE
	top.add_child(right)

	var score_stat := VBoxContainer.new()
	score_stat.custom_minimum_size = Vector2(60, 0)
	score_stat.mouse_filter = Control.MOUSE_FILTER_IGNORE
	right.add_child(score_stat)
	var score_cap := _static_label("score", 10, Color(0.70, 0.71, 0.79), HORIZONTAL_ALIGNMENT_LEFT)
	score_stat.add_child(score_cap)
	score_value = _raw_label("0", 19, GameData.BONE, HORIZONTAL_ALIGNMENT_LEFT)
	score_value.add_theme_font_override("font", font_bold)
	score_stat.add_child(score_value)

	var coin_stat := VBoxContainer.new()
	coin_stat.custom_minimum_size = Vector2(56, 0)
	coin_stat.mouse_filter = Control.MOUSE_FILTER_IGNORE
	right.add_child(coin_stat)
	var coin_cap := _static_label("coins", 10, Color(0.70, 0.71, 0.79), HORIZONTAL_ALIGNMENT_LEFT)
	coin_stat.add_child(coin_cap)
	coin_value = _raw_label("0", 19, GameData.GOLD, HORIZONTAL_ALIGNMENT_LEFT)
	coin_value.add_theme_font_override("font", font_bold)
	coin_stat.add_child(coin_value)

	var pause := Button.new()
	pause.text = "II"
	pause.custom_minimum_size = Vector2(40, 40)
	pause.focus_mode = Control.FOCUS_NONE
	pause.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	pause.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	pause.add_theme_font_override("font", font_bold)
	pause.add_theme_font_size_override("font_size", 12)
	_apply_ghost_button(pause)
	pause.pressed.connect(func(): main.pause_game())
	right.add_child(pause)

	hint_panel = _bottom_hint()
	hud.add_child(hint_panel)

func _bottom_hint() -> PanelContainer:
	var panel := PanelContainer.new()
	panel.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	panel.offset_left = -130
	panel.offset_right = 130
	panel.offset_top = -62
	panel.offset_bottom = -28
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var style := _stylebox(Color(0.03, 0.05, 0.12, 0.82), Color(1.0, 0.82, 0.48, 0.18), 18, 1)
	panel.add_theme_stylebox_override("panel", style)
	var label := _static_label("hint", 12, Color(0.80, 0.78, 0.74), HORIZONTAL_ALIGNMENT_CENTER)
	label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	panel.add_child(label)
	return panel

func _build_banner() -> void:
	banner_panel = PanelContainer.new()
	banner_panel.set_anchors_preset(Control.PRESET_CENTER_TOP)
	banner_panel.offset_left = -200
	banner_panel.offset_right = 200
	banner_panel.offset_top = 88
	banner_panel.offset_bottom = 166
	banner_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	banner_panel.visible = false
	var style := _stylebox(Color(0.035, 0.055, 0.12, 0.82), Color(1.0, 0.68, 0.28, 0.24), 8, 1)
	style.shadow_color = Color(0, 0, 0, 0.35)
	style.shadow_size = 12
	banner_panel.add_theme_stylebox_override("panel", style)
	root.add_child(banner_panel)
	var box := VBoxContainer.new()
	box.alignment = BoxContainer.ALIGNMENT_CENTER
	box.add_theme_constant_override("separation", 0)
	box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	banner_panel.add_child(box)
	banner_kicker = _raw_label("", 9, GameData.EMBER, HORIZONTAL_ALIGNMENT_CENTER)
	banner_kicker.add_theme_font_override("font", font_bold)
	box.add_child(banner_kicker)
	banner_title = _raw_label("", 27, GameData.BONE, HORIZONTAL_ALIGNMENT_CENTER)
	banner_title.add_theme_font_override("font", font_display)
	box.add_child(banner_title)
	banner_sub = _raw_label("", 10, Color(0.72, 0.70, 0.66), HORIZONTAL_ALIGNMENT_CENTER)
	box.add_child(banner_sub)

func _build_tutorial() -> void:
	tutorial_layer = _full_control()
	tutorial_layer.name = "Tutorial"
	root.add_child(tutorial_layer)
	_add_dim(tutorial_layer, 0.82)

	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	tutorial_layer.add_child(center)
	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(650, 410)
	panel.mouse_filter = Control.MOUSE_FILTER_STOP
	center.add_child(panel)
	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 28)
	margin.add_theme_constant_override("margin_right", 28)
	margin.add_theme_constant_override("margin_top", 20)
	margin.add_theme_constant_override("margin_bottom", 20)
	panel.add_child(margin)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 8)
	margin.add_child(box)

	var header := HBoxContainer.new()
	header.mouse_filter = Control.MOUSE_FILTER_IGNORE
	box.add_child(header)
	var title := _static_label("tutorial_title", 12, GameData.GOLD, HORIZONTAL_ALIGNMENT_LEFT)
	title.add_theme_font_override("font", font_bold)
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header.add_child(title)
	var close := Button.new()
	close.text = "X"
	close.custom_minimum_size = Vector2(34, 30)
	close.focus_mode = Control.FOCUS_NONE
	close.add_theme_font_size_override("font_size", 11)
	_apply_ghost_button(close)
	close.pressed.connect(func(): main.close_tutorial())
	header.add_child(close)

	tutorial_art = TutorialArt.new()
	tutorial_art.custom_minimum_size = Vector2(0, 136)
	tutorial_art.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	tutorial_art.mouse_filter = Control.MOUSE_FILTER_IGNORE
	box.add_child(tutorial_art)

	tutorial_page_title = _raw_label("", 28, GameData.BONE, HORIZONTAL_ALIGNMENT_CENTER)
	tutorial_page_title.add_theme_font_override("font", font_display)
	box.add_child(tutorial_page_title)

	tutorial_body = _raw_label("", 14, Color("#c5beb1"), HORIZONTAL_ALIGNMENT_CENTER)
	tutorial_body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	tutorial_body.custom_minimum_size = Vector2(570, 66)
	tutorial_body.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	box.add_child(tutorial_body)

	var dots := HBoxContainer.new()
	dots.alignment = BoxContainer.ALIGNMENT_CENTER
	dots.add_theme_constant_override("separation", 6)
	dots.mouse_filter = Control.MOUSE_FILTER_IGNORE
	box.add_child(dots)
	for i in 3:
		var dot := ColorRect.new()
		dot.custom_minimum_size = Vector2(18, 4)
		dot.color = Color(0.3, 0.3, 0.38)
		dot.mouse_filter = Control.MOUSE_FILTER_IGNORE
		dots.add_child(dot)
		tutorial_dots.append(dot)

	var spacer := Control.new()
	spacer.custom_minimum_size = Vector2(1, 4)
	box.add_child(spacer)

	var footer := HBoxContainer.new()
	footer.alignment = BoxContainer.ALIGNMENT_END
	footer.add_theme_constant_override("separation", 12)
	box.add_child(footer)
	tutorial_back = _button("back", false, 110, 42)
	tutorial_back.pressed.connect(func(): main.tutorial_back())
	footer.add_child(tutorial_back)
	tutorial_next = _button("next", true, 200, 48)
	tutorial_next.add_theme_font_size_override("font_size", 15)
	tutorial_next.pressed.connect(func(): main.tutorial_next())
	footer.add_child(tutorial_next)

func _build_shop() -> void:
	shop_layer = _full_control()
	shop_layer.name = "Shop"
	root.add_child(shop_layer)
	_add_dim(shop_layer, 0.78)

	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	shop_layer.add_child(center)
	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(810, 396)
	panel.mouse_filter = Control.MOUSE_FILTER_STOP
	center.add_child(panel)
	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 24)
	margin.add_theme_constant_override("margin_right", 24)
	margin.add_theme_constant_override("margin_top", 18)
	margin.add_theme_constant_override("margin_bottom", 16)
	panel.add_child(margin)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 12)
	margin.add_child(box)

	var header := HBoxContainer.new()
	header.mouse_filter = Control.MOUSE_FILTER_IGNORE
	box.add_child(header)
	var title_box := VBoxContainer.new()
	title_box.add_theme_constant_override("separation", 0)
	title_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	header.add_child(title_box)
	var kicker := _raw_label("BETWEEN WAVES", 9, GameData.EMBER, HORIZONTAL_ALIGNMENT_LEFT)
	kicker.add_theme_font_override("font", font_bold)
	title_box.add_child(kicker)
	var title := _static_label("shop_title", 30, GameData.BONE, HORIZONTAL_ALIGNMENT_LEFT)
	title.add_theme_font_override("font", font_display)
	title_box.add_child(title)
	var sub := _static_label("shop_sub", 11, Color(0.62, 0.62, 0.71), HORIZONTAL_ALIGNMENT_LEFT)
	title_box.add_child(sub)

	var coin_chip := PanelContainer.new()
	coin_chip.custom_minimum_size = Vector2(100, 44)
	coin_chip.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var chip_style := _stylebox(Color(1.0, 0.78, 0.34, 0.06), Color(1.0, 0.78, 0.34, 0.23), 8, 1)
	coin_chip.add_theme_stylebox_override("panel", chip_style)
	header.add_child(coin_chip)
	var chip_row := HBoxContainer.new()
	chip_row.alignment = BoxContainer.ALIGNMENT_CENTER
	chip_row.add_theme_constant_override("separation", 5)
	chip_row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	coin_chip.add_child(chip_row)
	shop_coins_value = _raw_label("0", 20, GameData.GOLD, HORIZONTAL_ALIGNMENT_RIGHT)
	shop_coins_value.add_theme_font_override("font", font_bold)
	chip_row.add_child(shop_coins_value)
	var coin_cap := _static_label("coins", 9, Color(0.66, 0.62, 0.53), HORIZONTAL_ALIGNMENT_LEFT)
	chip_row.add_child(coin_cap)

	var cards := HBoxContainer.new()
	cards.add_theme_constant_override("separation", 9)
	cards.size_flags_vertical = Control.SIZE_EXPAND_FILL
	cards.mouse_filter = Control.MOUSE_FILTER_IGNORE
	box.add_child(cards)
	for id in ["damage", "multishot", "quickdraw", "pierce", "repair"]:
		var card := _make_shop_card(id)
		cards.add_child(card)

	var footer := HBoxContainer.new()
	footer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	box.add_child(footer)
	shop_next_info = _raw_label("", 10, Color(0.61, 0.59, 0.67), HORIZONTAL_ALIGNMENT_LEFT)
	shop_next_info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	footer.add_child(shop_next_info)
	shop_next_button = _button("next_wave", true, 240, 48)
	shop_next_button.add_theme_font_size_override("font_size", 16)
	shop_next_button.pressed.connect(func(): main.next_wave())
	footer.add_child(shop_next_button)

func _make_shop_card(id: String) -> PanelContainer:
	var card := PanelContainer.new()
	card.custom_minimum_size = Vector2(144, 232)
	card.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var style := _stylebox(Color(0.095, 0.13, 0.25, 0.94), Color(0.95, 0.90, 0.80, 0.12), 9, 1)
	card.add_theme_stylebox_override("panel", style)
	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 10)
	margin.add_theme_constant_override("margin_right", 10)
	margin.add_theme_constant_override("margin_top", 11)
	margin.add_theme_constant_override("margin_bottom", 10)
	card.add_child(margin)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 4)
	margin.add_child(box)

	var accent_color := Color("#55c7b4") if id == "repair" else Color(str(Upgrades.DEFS[id]["accent"]))
	var accent := ColorRect.new()
	accent.color = accent_color
	accent.custom_minimum_size = Vector2(0, 2)
	accent.mouse_filter = Control.MOUSE_FILTER_IGNORE
	box.add_child(accent)

	var name_label := _raw_label("", 14, GameData.BONE, HORIZONTAL_ALIGNMENT_LEFT)
	name_label.add_theme_font_override("font", font_bold)
	name_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	name_label.custom_minimum_size = Vector2(0, 38)
	box.add_child(name_label)
	var desc := _raw_label("", 10, Color(0.65, 0.65, 0.74), HORIZONTAL_ALIGNMENT_LEFT)
	desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	desc.custom_minimum_size = Vector2(0, 44)
	box.add_child(desc)

	var art := UpgradeIcon.new()
	art.mode = id
	art.custom_minimum_size = Vector2(0, 42)
	art.mouse_filter = Control.MOUSE_FILTER_IGNORE
	box.add_child(art)

	var spacer := Control.new()
	spacer.size_flags_vertical = Control.SIZE_EXPAND_FILL
	box.add_child(spacer)

	var level_label := _raw_label("", 9, Color(0.59, 0.59, 0.68), HORIZONTAL_ALIGNMENT_LEFT)
	box.add_child(level_label)
	var pips := LevelPips.new()
	pips.custom_minimum_size = Vector2(0, 6)
	pips.maximum = 5
	pips.accent = accent_color
	pips.mouse_filter = Control.MOUSE_FILTER_IGNORE
	box.add_child(pips)

	var buy := _button("buy", id == "damage", 0, 34)
	buy.add_theme_font_size_override("font_size", 11)
	buy.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	if id == "repair":
		buy.pressed.connect(func(): main.repair_wall())
	else:
		buy.pressed.connect(main.buy_upgrade.bind(id))
	box.add_child(buy)

	shop_cards[id] = {
		"card": card,
		"name": name_label,
		"desc": desc,
		"level": level_label,
		"pips": pips,
		"buy": buy,
		"art": art,
		"accent": accent
	}
	return card

func _build_pause() -> void:
	pause_layer = _full_control()
	pause_layer.name = "Pause"
	root.add_child(pause_layer)
	_add_dim(pause_layer, 0.72)

	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	pause_layer.add_child(center)
	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(400, 330)
	panel.mouse_filter = Control.MOUSE_FILTER_STOP
	center.add_child(panel)
	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 28)
	margin.add_theme_constant_override("margin_right", 28)
	margin.add_theme_constant_override("margin_top", 24)
	margin.add_theme_constant_override("margin_bottom", 22)
	panel.add_child(margin)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 9)
	box.alignment = BoxContainer.ALIGNMENT_CENTER
	margin.add_child(box)

	var title := _static_label("pause", 36, GameData.BONE, HORIZONTAL_ALIGNMENT_CENTER)
	title.add_theme_font_override("font", font_display)
	box.add_child(title)
	var sub := _static_label("pause_sub", 12, Color(0.65, 0.64, 0.71), HORIZONTAL_ALIGNMENT_CENTER)
	box.add_child(sub)
	var spacer := Control.new()
	spacer.custom_minimum_size = Vector2(1, 8)
	box.add_child(spacer)
	var resume := _button("resume", true, 310, 48)
	resume.add_theme_font_size_override("font_size", 15)
	resume.pressed.connect(func(): main.resume_game())
	box.add_child(resume)
	var restart := _button("restart", false, 310, 42)
	restart.add_theme_font_size_override("font_size", 14)
	restart.pressed.connect(func(): main.restart_run())
	box.add_child(restart)
	var menu := _button("menu", false, 310, 42)
	menu.add_theme_font_size_override("font_size", 14)
	menu.pressed.connect(func(): main.quit_to_menu())
	box.add_child(menu)

func _build_result() -> void:
	result_layer = _full_control()
	result_layer.name = "Result"
	root.add_child(result_layer)
	result_dim = _add_dim(result_layer, 0.82)

	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	result_layer.add_child(center)
	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(570, 404)
	panel.mouse_filter = Control.MOUSE_FILTER_STOP
	center.add_child(panel)
	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 28)
	margin.add_theme_constant_override("margin_right", 28)
	margin.add_theme_constant_override("margin_top", 22)
	margin.add_theme_constant_override("margin_bottom", 20)
	panel.add_child(margin)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 6)
	box.alignment = BoxContainer.ALIGNMENT_CENTER
	margin.add_child(box)

	result_title = _raw_label("", 44, GameData.BONE, HORIZONTAL_ALIGNMENT_CENTER)
	result_title.add_theme_font_override("font", font_display)
	box.add_child(result_title)
	result_sub = _raw_label("", 12, Color(0.70, 0.67, 0.70), HORIZONTAL_ALIGNMENT_CENTER)
	box.add_child(result_sub)
	result_new_best = _static_label("new_best", 11, GameData.GOLD, HORIZONTAL_ALIGNMENT_CENTER)
	result_new_best.add_theme_font_override("font", font_bold)
	result_new_best.visible = false
	box.add_child(result_new_best)

	var spacer := Control.new()
	spacer.custom_minimum_size = Vector2(1, 8)
	box.add_child(spacer)

	var stats := HBoxContainer.new()
	stats.alignment = BoxContainer.ALIGNMENT_CENTER
	stats.add_theme_constant_override("separation", 8)
	stats.mouse_filter = Control.MOUSE_FILTER_IGNORE
	box.add_child(stats)
	result_wave_value = _make_stat(stats, "wave_reached")
	result_kills_value = _make_stat(stats, "kills")
	result_score_value = _make_stat(stats, "score")
	result_best_value = _make_stat(stats, "best_score")

	var spacer2 := Control.new()
	spacer2.custom_minimum_size = Vector2(1, 8)
	box.add_child(spacer2)

	result_again_button = _button("play_again", true, 310, 48)
	result_again_button.add_theme_font_size_override("font_size", 15)
	result_again_button.pressed.connect(func(): main.start_run())
	box.add_child(result_again_button)
	result_menu_button = _button("menu", false, 310, 42)
	result_menu_button.add_theme_font_size_override("font_size", 14)
	result_menu_button.pressed.connect(func(): main.quit_to_menu())
	box.add_child(result_menu_button)

func _make_stat(parent: HBoxContainer, key: String) -> Label:
	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(118, 66)
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var style := _stylebox(Color(0.06, 0.09, 0.18, 0.75), Color(0.95, 0.90, 0.80, 0.08), 8, 1)
	panel.add_theme_stylebox_override("panel", style)
	parent.add_child(panel)
	var box := VBoxContainer.new()
	box.alignment = BoxContainer.ALIGNMENT_CENTER
	box.add_theme_constant_override("separation", 0)
	box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.add_child(box)
	var value := _raw_label("0", 22, GameData.BONE, HORIZONTAL_ALIGNMENT_CENTER)
	value.add_theme_font_override("font", font_bold)
	value.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	box.add_child(value)
	var cap := _static_label(key, 9, Color(0.60, 0.59, 0.67), HORIZONTAL_ALIGNMENT_CENTER)
	cap.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	box.add_child(cap)
	return value

func _full_control() -> Control:
	var c := Control.new()
	c.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	c.mouse_filter = Control.MOUSE_FILTER_STOP
	c.visible = false
	return c

func _add_dim(parent: Control, alpha: float) -> ColorRect:
	var dim := ColorRect.new()
	dim.color = Color(0.015, 0.025, 0.06, alpha)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(dim)
	return dim

func _raw_label(text: String, size: int, color: Color, align: HorizontalAlignment) -> Label:
	var l := Label.new()
	l.text = text
	l.horizontal_alignment = align
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	l.add_theme_font_override("font", font_body)
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l

func _static_label(key: String, size: int, color: Color, align: HorizontalAlignment) -> Label:
	var l := _raw_label(I18n.t(_lang(), key), size, color, align)
	static_labels.append({"node": l, "key": key})
	return l

func _button(key: String, primary: bool, width: int, height: int) -> Button:
	var b := Button.new()
	b.text = I18n.t(_lang(), key)
	b.custom_minimum_size = Vector2(width, height)
	b.focus_mode = Control.FOCUS_NONE
	b.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	b.add_theme_font_override("font", font_bold)
	b.add_theme_font_size_override("font_size", 14)
	b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	if primary:
		_apply_primary_button(b)
	else:
		_apply_ghost_button(b)
	static_buttons.append({"node": b, "key": key, "primary": primary})
	return b

func _apply_primary_button(b: Button) -> void:
	var normal := _stylebox(Color("#ffb03a"), Color(1.0, 0.86, 0.55, 0.65), 8, 1)
	normal.shadow_color = Color(1.0, 0.42, 0.12, 0.18)
	normal.shadow_size = 10
	var hover := _stylebox(Color("#ffc35c"), Color(1.0, 0.92, 0.70, 0.9), 8, 1)
	var pressed := _stylebox(Color("#e56b25"), Color(1.0, 0.75, 0.40, 0.8), 8, 1)
	var disabled := _stylebox(Color(0.38, 0.30, 0.22, 0.7), Color(1.0, 0.82, 0.50, 0.12), 8, 1)
	b.add_theme_stylebox_override("normal", normal)
	b.add_theme_stylebox_override("hover", hover)
	b.add_theme_stylebox_override("pressed", pressed)
	b.add_theme_stylebox_override("disabled", disabled)
	b.add_theme_color_override("font_color", Color("#1a0d07"))
	b.add_theme_color_override("font_hover_color", Color("#1a0d07"))
	b.add_theme_color_override("font_pressed_color", Color("#1a0d07"))
	b.add_theme_color_override("font_disabled_color", Color(0.62, 0.54, 0.43, 0.75))

func _apply_ghost_button(b: Button) -> void:
	var normal := _stylebox(Color(0.04, 0.06, 0.13, 0.65), Color(0.95, 0.90, 0.80, 0.14), 8, 1)
	var hover := _stylebox(Color(0.10, 0.13, 0.24, 0.9), Color(1.0, 0.80, 0.40, 0.38), 8, 1)
	var pressed := _stylebox(Color(0.06, 0.08, 0.16, 0.95), Color(1.0, 0.70, 0.30, 0.6), 8, 1)
	var disabled := _stylebox(Color(0.04, 0.05, 0.1, 0.4), Color(0.95, 0.90, 0.80, 0.05), 8, 1)
	b.add_theme_stylebox_override("normal", normal)
	b.add_theme_stylebox_override("hover", hover)
	b.add_theme_stylebox_override("pressed", pressed)
	b.add_theme_stylebox_override("disabled", disabled)
	b.add_theme_color_override("font_color", Color(0.88, 0.85, 0.80))
	b.add_theme_color_override("font_hover_color", Color(1.0, 0.88, 0.62))
	b.add_theme_color_override("font_pressed_color", Color(1.0, 0.88, 0.62))
	b.add_theme_color_override("font_disabled_color", Color(0.55, 0.53, 0.58, 0.45))

func _stylebox(bg: Color, border: Color, radius: int, border_width: int) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(border_width)
	s.set_corner_radius_all(radius)
	return s

func _lang() -> String:
	return str(main.language) if main else "ar"

func apply_safe_area() -> void:
	var left := 14
	var top := 10
	var right := 14
	var bottom := 10
	if OS.has_feature("mobile"):
		var win := Vector2(DisplayServer.window_get_size())
		var safe := DisplayServer.get_display_safe_area()
		var vp_size := get_viewport().get_visible_rect().size
		if win.x > 0.0 and win.y > 0.0:
			var sx := vp_size.x / win.x
			var sy := vp_size.y / win.y
			left = maxi(left, int(round(float(safe.position.x) * sx)))
			top = maxi(top, int(round(float(safe.position.y) * sy)))
			right = maxi(right, int(round(float(win.x - safe.end.x) * sx)))
			bottom = maxi(bottom, int(round(float(win.y - safe.end.y) * sy)))
	if safe_margin:
		safe_margin.add_theme_constant_override("margin_left", left)
		safe_margin.add_theme_constant_override("margin_right", right)
		safe_margin.add_theme_constant_override("margin_top", top)
		safe_margin.add_theme_constant_override("margin_bottom", bottom)

func _process(_delta: float) -> void:
	if main == null:
		return
	vignette.strength = main.wall_flash
	vignette.low_health = clampf(1.0 - main.get_wall_ratio(), 0.0, 1.0)
	if hud.visible:
		var ratio: float = main.get_wall_ratio()
		wall_bar.value = ratio * 100.0
		wall_value.text = "%d%%" % int(round(ratio * 100.0))
		wave_num.text = "%02d" % int(main.wave)
		wave_total.text = "%02d" % GameData.TOTAL_WAVES
		score_value.text = GameData.format_number(int(main.score))
		coin_value.text = GameData.format_number(int(main.coins))
		boss_box.visible = bool(main.boss_active)
		if main.boss_active:
			boss_bar.value = main.get_boss_ratio() * 100.0
		var low: bool = ratio < 0.34
		if low != low_wall_style:
			low_wall_style = low
			wall_bar.add_theme_stylebox_override("fill", fill_low if low else fill_normal)
		hint_panel.visible = bool(main.is_playing()) and int(main.wave) == 1 and not bool(main.hint_seen) and not bool(main.aiming)

func _unhandled_input(event: InputEvent) -> void:
	pass

func show_menu() -> void:
	_hide_all()
	hud.visible = false
	menu_layer.visible = true
	banner_panel.visible = false
	_refresh_menu_texts()
	_update_menu_stats()

func show_hud() -> void:
	_hide_all()
	hud.visible = true
	banner_panel.visible = false

func hide_overlays() -> void:
	_hide_all()
	hud.visible = true
	banner_panel.visible = false

func show_shop() -> void:
	_hide_all()
	hud.visible = false
	shop_layer.visible = true
	banner_panel.visible = false
	refresh_shop()

func show_tutorial() -> void:
	_hide_all()
	hud.visible = false
	tutorial_layer.visible = true
	banner_panel.visible = false
	refresh_tutorial()

func show_pause() -> void:
	pause_layer.visible = true
	banner_panel.visible = false

func show_result(victory: bool) -> void:
	_hide_all()
	hud.visible = false
	result_victory = victory
	banner_panel.visible = false
	result_dim.color = Color(0.015, 0.025, 0.06, 0.58 if victory else 0.82)
	result_layer.visible = true
	result_title.text = I18n.t(_lang(), "victory_title" if victory else "defeat_title")
	result_sub.text = I18n.t(_lang(), "victory_sub" if victory else "defeat_sub")
	result_wave_value.text = "%02d" % int(main.wave)
	result_kills_value.text = str(int(main.kills))
	result_score_value.text = GameData.format_number(int(main.score))
	result_best_value.text = GameData.format_number(int(main.high_score))
	result_new_best.visible = bool(main.new_best)
	result_again_button.text = I18n.t(_lang(), "play_again")
	result_menu_button.text = I18n.t(_lang(), "menu")

func _hide_all() -> void:
	menu_layer.visible = false
	tutorial_layer.visible = false
	shop_layer.visible = false
	pause_layer.visible = false
	result_layer.visible = false

func show_banner(title: String, subtitle: String, kicker: String) -> void:
	banner_title.text = title
	banner_sub.text = subtitle
	banner_kicker.text = kicker
	banner_panel.visible = true
	banner_panel.modulate = Color(1, 1, 1, 1)
	if banner_tween and banner_tween.is_valid():
		banner_tween.kill()
	banner_tween = create_tween()
	banner_tween.tween_interval(1.25)
	banner_tween.tween_property(banner_panel, "modulate:a", 0.0, 0.65)
	banner_tween.tween_callback(func(): banner_panel.visible = false)

func refresh_language() -> void:
	for entry in static_labels:
		var node: Label = entry["node"]
		node.text = I18n.t(_lang(), str(entry["key"]))
	for entry in static_buttons:
		var b: Button = entry["node"]
		b.text = I18n.t(_lang(), str(entry["key"]))
		if str(entry["key"]) == "next_wave":
			b.text = I18n.t(_lang(), "next_wave")
	sound_button.text = I18n.t(_lang(), "sound_on" if bool(main.sound_on) else "sound_off")
	_refresh_menu_texts()
	_update_menu_stats()
	refresh_tutorial()
	if shop_layer.visible:
		refresh_shop()
	if result_layer.visible:
		result_title.text = I18n.t(_lang(), "victory_title" if result_victory else "defeat_title")
		result_sub.text = I18n.t(_lang(), "victory_sub" if result_victory else "defeat_sub")
		result_again_button.text = I18n.t(_lang(), "play_again")
		result_menu_button.text = I18n.t(_lang(), "menu")

func _refresh_menu_texts() -> void:
	menu_eyebrow.text = "EMBERWALL" if _lang() == "ar" else "حصن الجمر"
	menu_title.text = I18n.t(_lang(), "title")
	menu_title.add_theme_font_size_override("font_size", 64 if _lang() == "ar" else 56)
	night_label.text = "NIGHT 01 / 12"

func _update_menu_stats() -> void:
	if menu_best:
		menu_best.text = "%s  %s   •   %s  %s" % [
			I18n.t(_lang(), "best"), GameData.format_number(int(main.high_score)),
			I18n.t(_lang(), "best_wave"), str(int(main.best_wave))
		]

func refresh_tutorial() -> void:
	if main == null:
		return
	var page := int(main.tutorial_page)
	tutorial_art.mode = page
	tutorial_art.queue_redraw()
	tutorial_page_title.text = I18n.t(_lang(), "tutorial_%d_title" % (page + 1))
	tutorial_body.text = I18n.t(_lang(), "tutorial_%d_body" % (page + 1))
	tutorial_back.disabled = page == 0
	if page >= 2:
		tutorial_next.text = I18n.t(_lang(), "begin" if bool(main.tutorial_start_after) else "done")
	else:
		tutorial_next.text = I18n.t(_lang(), "next")
	for i in tutorial_dots.size():
		var dot: ColorRect = tutorial_dots[i]
		dot.color = GameData.GOLD if i == page else Color(0.28, 0.29, 0.36)

func refresh_shop() -> void:
	if main == null:
		return
	shop_coins_value.text = GameData.format_number(int(main.coins))
	for id in ["damage", "multishot", "quickdraw", "pierce"]:
		var data: Dictionary = shop_cards[id]
		var level := int(main.upgrades.get(id, 0))
		var max_level := int(Upgrades.DEFS[id]["max"])
		var name_label: Label = data["name"]
		var desc_label: Label = data["desc"]
		var level_label: Label = data["level"]
		var pips: LevelPips = data["pips"]
		var buy: Button = data["buy"]
		name_label.text = Upgrades.name_for(id, _lang())
		desc_label.text = Upgrades.desc_for(id, _lang())
		level_label.text = I18n.t(_lang(), "level", {"a": level, "b": max_level})
		pips.filled = level
		pips.maximum = max_level
		pips.queue_redraw()
		if level >= max_level:
			buy.text = I18n.t(_lang(), "max")
			buy.disabled = true
		else:
			var price := Upgrades.cost(id, level)
			buy.text = I18n.t(_lang(), "buy", {"n": price})
			buy.disabled = int(main.coins) < price
	var repair: Dictionary = shop_cards["repair"]
	var repair_buy: Button = repair["buy"]
	var repair_level: Label = repair["level"]
	var repair_pips: LevelPips = repair["pips"]
	repair["name"].text = I18n.t(_lang(), "repair_name")
	repair["desc"].text = I18n.t(_lang(), "repair_desc")
	repair_level.text = "%s  %d%%" % [I18n.t(_lang(), "wall"), int(round(main.get_wall_ratio() * 100.0))]
	repair_pips.filled = int(ceil(main.get_wall_ratio() * 5.0))
	repair_pips.maximum = 5
	repair_pips.queue_redraw()
	if main.wall_hp >= GameData.WALL_MAX - 0.01:
		repair_buy.text = I18n.t(_lang(), "full")
		repair_buy.disabled = true
	else:
		var repair_price := Upgrades.repair_cost(int(main.repair_count))
		repair_buy.text = I18n.t(_lang(), "buy", {"n": repair_price})
		repair_buy.disabled = int(main.coins) < repair_price
	shop_next_info.text = "%s  •  %s" % [
		I18n.t(_lang(), "next_wave_named", {"n": int(main.wave) + 1}),
		main.get_next_wave_title()
	]
	shop_next_button.text = I18n.t(_lang(), "next_wave")

func flash_shop_coins() -> void:
	if not shop_coins_value:
		return
	var tween := create_tween()
	tween.tween_property(shop_coins_value, "modulate", Color("#ff8b8b"), 0.08)
	tween.tween_property(shop_coins_value, "modulate", Color(1, 1, 1, 1), 0.28)
