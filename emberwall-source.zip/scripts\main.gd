extends Node

enum State { MENU, TUTORIAL, PLAYING, SHOP, PAUSED, DEFEAT, VICTORY }

var world: WorldView
var ui: GameUI
var audio: GameAudio

var state: int = State.MENU
var previous_state: int = State.MENU

var language := "ar"
var sound_on := true
var save_data: Dictionary = {}
var high_score := 0
var best_wave := 1
var new_best := false

var wave := 1
var coins := 0
var score := 0
var wall_hp := GameData.WALL_MAX
var upgrades := {"damage": 0, "multishot": 0, "quickdraw": 0, "pierce": 0}
var repair_count := 0
var kills := 0
var shots_fired := 0

var enemies: Array = []
var arrows: Array = []
var rocks: Array = []
var effects: Array = []
var spawn_queue: Array = []
var spawned_count := 0
var wave_elapsed := 0.0
var wave_bonus := 0
var wave_cleared := false
var next_enemy_id := 1

var boss_active := false
var boss_hp := 0.0
var boss_max_hp := 0.0

var aiming := false
var aim_start := Vector2.ZERO
var aim_current := Vector2.ZERO
var aim_dir := Vector2.RIGHT
var aim_speed := 0.0
var aim_power := 0.0
var aim_preview: Array = []
var cooldown := 0.0
var recoil := 0.0

var shake := 0.0
var wall_flash := 0.0
var dawn := 0.0
var elapsed := 0.0
var defeat_timer := -1.0
var shop_timer := -1.0
var victory_timer := -1.0
var tutorial_page := 0
var tutorial_start_after := false
var run_active := false
var viewport_size := Vector2(840, 480)
var stage_offset := 0.0
var hint_seen := false

func _ready() -> void:
	save_data = SaveGame.load_game()
	language = str(save_data["language"])
	sound_on = bool(save_data["sound"])
	high_score = int(save_data["high_score"])
	best_wave = int(save_data["best_wave"])
	run_active = false
	wall_hp = GameData.WALL_MAX
	wave = 1

	world = WorldView.new()
	world.main = self
	add_child(world)

	audio = GameAudio.new()
	audio.enabled = sound_on
	add_child(audio)

	ui = GameUI.new()
	ui.main = self
	add_child(ui)

	viewport_size = get_viewport().get_visible_rect().size
	stage_offset = GameData.stage_offset_y(viewport_size.y)
	get_viewport().size_changed.connect(_on_viewport_resized)
	ui.show_menu()
	set_process(true)
	set_process_unhandled_input(true)

func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT or what == NOTIFICATION_WM_WINDOW_FOCUS_OUT:
		if state == State.PLAYING and defeat_timer < 0 and shop_timer < 0 and victory_timer < 0:
			pause_game()

func _on_viewport_resized() -> void:
	viewport_size = get_viewport().get_visible_rect().size
	stage_offset = GameData.stage_offset_y(viewport_size.y)
	if ui:
		ui.apply_safe_area()

func _process(delta: float) -> void:
	elapsed += delta
	viewport_size = get_viewport().get_visible_rect().size
	stage_offset = GameData.stage_offset_y(viewport_size.y)
	cooldown = maxf(0.0, cooldown - delta)
	recoil = move_toward(recoil, 0.0, delta * 6.0)
	shake = maxf(0.0, shake - delta * 26.0)
	wall_flash = maxf(0.0, wall_flash - delta * 2.3)

	if state != State.PAUSED:
		_update_effects(delta)

	match state:
		State.PLAYING:
			if defeat_timer >= 0.0:
				defeat_timer -= delta
				if defeat_timer <= 0.0:
					_finish_defeat()
			elif victory_timer >= 0.0:
				victory_timer -= delta
				if victory_timer <= 0.0:
					_finish_victory()
			elif shop_timer >= 0.0:
				shop_timer -= delta
				if shop_timer <= 0.0:
					_open_shop()
			else:
				_update_playing(delta)
		State.VICTORY:
			dawn = minf(1.0, dawn + delta * 0.42)

func _update_playing(delta: float) -> void:
	wave_elapsed += delta
	while spawned_count < spawn_queue.size() and wave_elapsed >= float(spawn_queue[spawned_count]["time"]):
		_spawn_enemy(str(spawn_queue[spawned_count]["type"]))
		spawned_count += 1

	_update_enemies(delta)
	_update_rocks(delta)
	_update_arrows(delta)

	if not wave_cleared and spawned_count >= spawn_queue.size() and _living_enemy_count() == 0 and wave_elapsed > 0.7:
		_on_wave_cleared()

func _update_enemies(delta: float) -> void:
	var kept: Array = []
	for e in enemies:
		e["anim_time"] = float(e["anim_time"]) + delta
		e["hit_flash"] = maxf(0.0, float(e["hit_flash"]) - delta * 6.0)
		e["attack_anim"] = maxf(0.0, float(e["attack_anim"]) - delta * 4.0)

		if str(e["state"]) == "dead":
			e["death_timer"] = float(e["death_timer"]) - delta
			if float(e["death_timer"]) > 0.0:
				kept.append(e)
			continue

		var stop_x := float(e["stop_x"])
		if float(e["x"]) > stop_x:
			e["x"] = maxf(stop_x, float(e["x"]) - float(e["speed"]) * delta)
			if float(e["x"]) <= stop_x + 0.5:
				e["attack_timer"] = 0.65
		else:
			var kind := str(e["kind"])
			if kind == "suicide":
				_explode_torch(e)
				kept.append(e)
				continue
			e["attack_timer"] = float(e["attack_timer"]) - delta
			if float(e["attack_timer"]) <= 0.0:
				e["attack_timer"] = float(e["attack_interval"])
				e["attack_anim"] = 1.0
				if kind == "ranged":
					_throw_rock(e)
				else:
					_damage_wall(float(e["damage"]))
		kept.append(e)
	enemies = kept

func _update_rocks(delta: float) -> void:
	var kept: Array = []
	for r in rocks:
		if bool(r.get("dead", false)):
			continue
		r["pos"] = Vector2(r["pos"]) + Vector2(r["vel"]) * delta
		r["vel"] = Vector2(r["vel"]) + Vector2(0.0, GameData.GRAVITY * 0.86) * delta
		r["spin"] = float(r["spin"]) + delta * 9.0
		var p: Vector2 = r["pos"]
		if p.x <= GameData.WALL_X + 15.0 and p.y > 275.0:
			_damage_wall(float(r["damage"]))
			_burst(p, Color("#d59a63"), 8, 95.0)
			continue
		if p.y >= GameData.GROUND_Y or p.x < -70.0:
			_burst(p, Color("#6f5a4a"), 5, 55.0)
			continue
		kept.append(r)
	rocks = kept

func _update_arrows(delta: float) -> void:
	var kept: Array = []
	for a in arrows:
		if bool(a.get("dead", false)):
			continue
		a["prev"] = a["pos"]
		a["vel"] = Vector2(a["vel"]) + Vector2(0.0, GameData.GRAVITY) * delta
		a["pos"] = Vector2(a["pos"]) + Vector2(a["vel"]) * delta
		a["life"] = float(a["life"]) + delta
		var trail: Array = a["trail"]
		trail.push_front(a["pos"])
		if trail.size() > 7:
			trail.pop_back()

		var p: Vector2 = a["pos"]
		var prev: Vector2 = a["prev"]

		var hit_rock := false
		for r in rocks:
			if bool(r.get("dead", false)):
				continue
			if GameData.segment_circle_hit(prev, p, Vector2(r["pos"]), 11.0):
				r["dead"] = true
				coins += 1
				_add_effect_text(Vector2(r["pos"]) + Vector2(0, -18), "+1", GameData.GOLD, 15, 0.55)
				_burst(Vector2(r["pos"]), Color("#9a8d84"), 7, 80.0)
				audio.play_sfx("hit", 1.3, -6.0)
				a["dead"] = true
				hit_rock = true
				break
		if hit_rock:
			continue

		var target := _find_arrow_target(a)
		if not target.is_empty():
			var e: Dictionary = target["enemy"]
			var headshot := bool(target["head"])
			var base_damage := float(a["damage"])
			var damage := base_damage * 2.0 if headshot else base_damage * (1.0 - float(e["armor"]))
			_damage_enemy(e, damage, headshot, Vector2(target["point"]))
			var hits: Array = a["hits"]
			hits.append(int(e["id"]))
			a["hits_left"] = int(a["hits_left"]) - 1
			if int(a["hits_left"]) <= 0:
				a["dead"] = true
				continue
			a["damage"] = base_damage * 0.85

		if p.y >= GameData.GROUND_Y:
			_add_stuck_arrow(Vector2(p.x, GameData.GROUND_Y - 2.0), atan2(float(a["vel"].y), float(a["vel"].x)))
			_burst(Vector2(p.x, GameData.GROUND_Y), Color("#6b5a48"), 4, 40.0)
			a["dead"] = true
			continue
		if p.x < GameData.WALL_X - 30.0 or p.x > viewport_size.x + 100.0 or p.y < -200.0:
			a["dead"] = true
			continue
		kept.append(a)
	arrows = kept

func _find_arrow_target(a: Dictionary) -> Dictionary:
	var best: Dictionary = {}
	var best_dist := INF
	var prev: Vector2 = a["prev"]
	var p: Vector2 = a["pos"]
	var hits: Array = a["hits"]
	for e in enemies:
		if str(e["state"]) == "dead" or hits.has(int(e["id"])):
			continue
		var head_pos := _head_center(e)
		var head_r := _head_radius(e)
		if GameData.segment_circle_hit(prev, p, head_pos, head_r):
			var point := GameData.closest_on_segment(prev, p, head_pos)
			var d := prev.distance_to(point)
			if d < best_dist:
				best = {"enemy": e, "head": true, "point": point}
				best_dist = d
		var body_pos := _body_center(e)
		var body_r := _body_radius(e)
		if GameData.segment_circle_hit(prev, p, body_pos, body_r):
			var point2 := GameData.closest_on_segment(prev, p, body_pos)
			var d2 := prev.distance_to(point2)
			if d2 < best_dist:
				best = {"enemy": e, "head": false, "point": point2}
				best_dist = d2
	return best

func _head_center(e: Dictionary) -> Vector2:
	return Vector2(float(e["x"]), GameData.GROUND_Y - float(e["height"]) * 0.88)

func _head_radius(e: Dictionary) -> float:
	return float(e["height"]) * 0.145

func _body_center(e: Dictionary) -> Vector2:
	return Vector2(float(e["x"]), GameData.GROUND_Y - float(e["height"]) * 0.47)

func _body_radius(e: Dictionary) -> float:
	return float(e["height"]) * (0.31 if bool(e.get("boss", false)) else 0.27)

func _spawn_enemy(type: String) -> void:
	var stats := EnemyTypes.get_stats(type, wave)
	var e := stats.duplicate(true)
	e["id"] = next_enemy_id
	next_enemy_id += 1
	e["state"] = "alive"
	e["x"] = viewport_size.x + 45.0 + randf_range(0.0, 50.0)
	e["anim_time"] = randf_range(0.0, 9.0)
	e["hit_flash"] = 0.0
	e["attack_anim"] = 0.0
	e["attack_timer"] = 0.85
	e["death_timer"] = 0.0
	e["boss"] = bool(stats.get("boss", false))
	var height := float(e["height"])
	if e["boss"]:
		e["stop_x"] = GameData.WALL_X + 54.0
		e["attack_interval"] = 1.35
	elif str(e["kind"]) == "ranged":
		e["stop_x"] = maxf(GameData.WALL_X + 140.0, viewport_size.x * 0.56)
		e["attack_interval"] = 2.65
	elif str(e["kind"]) == "suicide":
		e["stop_x"] = GameData.WALL_X + 28.0
		e["attack_interval"] = 0.0
	else:
		e["stop_x"] = GameData.WALL_X + 25.0 + height * 0.10
		e["attack_interval"] = 1.15
	if e["boss"]:
		boss_active = true
		boss_hp = float(e["hp"])
		boss_max_hp = float(e["max_hp"])
		ui.show_banner(I18n.t(language, "boss"), I18n.t(language, "boss_incoming"), "")
		audio.play_sfx("horn", 0.82, -1.0)
		shake = 8.0
	enemies.append(e)

func _explode_torch(e: Dictionary) -> void:
	if str(e["state"]) == "dead":
		return
	_damage_wall(float(e["damage"]))
	_burst(Vector2(float(e["x"]), GameData.GROUND_Y - 20.0), Color("#ff9b54"), 22, 180.0)
	_add_ring(Vector2(float(e["x"]), GameData.GROUND_Y - 16.0), Color("#ffb257"), 60.0)
	audio.play_sfx("explode", 1.05, -2.0)
	shake = maxf(shake, 9.0)
	_kill_enemy(e, false, false)

func _throw_rock(e: Dictionary) -> void:
	var start := Vector2(float(e["x"]) - 14.0, GameData.GROUND_Y - float(e["height"]) * 0.58)
	var target := Vector2(GameData.WALL_X + 12.0, 334.0 + randf_range(-16.0, 16.0))
	var travel := 1.05
	var vx := (target.x - start.x) / travel
	var vy := (target.y - start.y - 0.5 * GameData.GRAVITY * 0.86 * travel * travel) / travel
	rocks.append({"pos": start, "vel": Vector2(vx, vy), "damage": 6.0, "spin": 0.0, "dead": false})
	audio.play_sfx("bow", 0.64, -7.0)
	_burst(start, Color("#7f7568"), 3, 30.0)

func _damage_enemy(e: Dictionary, damage: float, headshot: bool, point: Vector2) -> void:
	if str(e["state"]) == "dead":
		return
	e["hp"] = float(e["hp"]) - damage
	e["hit_flash"] = 1.0
	var shown := int(round(damage))
	var color := GameData.GOLD if headshot else GameData.BONE
	_add_effect_text(point + Vector2(0, -18), str(shown), color, 22 if headshot else 17, 0.65)
	if headshot:
		_add_effect_text(point + Vector2(0, -38), "HEADSHOT", Color("#ffe3a0"), 9, 0.75)
	_burst(point, Color("#ffc857") if headshot else Color("#e8d8bf"), 8 if headshot else 5, 100.0 if headshot else 65.0)
	audio.play_sfx("headshot" if headshot else "hit", 1.0 if not headshot else randf_range(0.98, 1.08), -2.0)
	shake = maxf(shake, 2.2 if not headshot else 3.6)
	if headshot and OS.has_feature("mobile"):
		Input.vibrate_handheld(8)
	if float(e["hp"]) <= 0.0:
		_kill_enemy(e, true, headshot)

func _kill_enemy(e: Dictionary, award: bool, headshot: bool) -> void:
	if str(e["state"]) == "dead":
		return
	e["state"] = "dead"
	e["death_timer"] = 0.68
	e["attack_anim"] = 0.0
	var pos := Vector2(float(e["x"]), GameData.GROUND_Y - float(e["height"]) * 0.5)
	if award:
		coins += int(e["coins"])
		score += int(e["score"]) * (2 if headshot else 1)
		kills += 1
		_add_coin_burst(pos, int(e["coins"]))
		_add_effect_text(pos + Vector2(0, -40), "+" + str(int(e["coins"])), GameData.GOLD, 14, 0.65)
	if bool(e.get("boss", false)):
		boss_active = false
		boss_hp = 0.0
		shake = 13.0
		audio.play_sfx("explode", 0.82, 0.0)
		_burst(pos, Color("#ff9b54"), 36, 250.0)
		_add_ring(pos, Color("#ffc857"), 130.0)
		if OS.has_feature("mobile"):
			Input.vibrate_handheld(60)
	else:
		audio.play_sfx("kill", randf_range(0.88, 1.08), -4.0)
		_burst(pos, Color("#7c4a3c"), 12, 120.0)
		shake = maxf(shake, 4.5)

func _damage_wall(amount: float) -> void:
	if state != State.PLAYING or defeat_timer >= 0.0:
		return
	wall_hp = maxf(0.0, wall_hp - amount)
	wall_flash = 1.0
	shake = maxf(shake, 4.5 + amount * 0.25)
	audio.play_sfx("wall", randf_range(0.92, 1.06), -2.0)
	_burst(Vector2(GameData.WALL_X + 8.0, 330.0 + randf_range(-30.0, 40.0)), Color("#8f7e6f"), 10, 90.0)
	_add_effect_text(Vector2(GameData.WALL_X + 30.0, 275.0), "-" + str(int(amount)), GameData.BLOOD, 15, 0.7)
	if OS.has_feature("mobile"):
		Input.vibrate_handheld(18)
	if wall_hp <= 0.0:
		_begin_defeat()

func _begin_defeat() -> void:
	defeat_timer = 1.45
	aiming = false
	aim_preview.clear()
	audio.play_sfx("defeat", 1.0, 0.0)
	shake = 14.0
	_record_progress()

func _finish_defeat() -> void:
	state = State.DEFEAT
	run_active = false
	aiming = false
	ui.show_result(false)
	_record_progress()

func _finish_victory() -> void:
	if state == State.VICTORY:
		return
	state = State.VICTORY
	run_active = false
	aiming = false
	score += int(wall_hp) * 5
	_record_progress()
	ui.show_result(true)
	audio.play_sfx("victory", 1.0, 0.0)
	shake = 3.0

func _on_wave_cleared() -> void:
	wave_cleared = true
	wave_bonus = Levels.wave_bonus(wave)
	coins += wave_bonus
	score += 100 * wave
	audio.play_sfx("horn", 1.05, -3.0)
	ui.show_banner(I18n.t(language, "wave_cleared"), I18n.t(language, "wave_bonus", {"n": wave_bonus}), "")
	_burst(Vector2(GameData.WALL_X + 30.0, 270.0), Color("#ffc857"), 15, 120.0)
	if wave >= GameData.TOTAL_WAVES:
		victory_timer = 1.8
	else:
		shop_timer = 1.55

func _open_shop() -> void:
	shop_timer = -1.0
	state = State.SHOP
	aiming = false
	aim_preview.clear()
	_record_progress()
	ui.show_shop()
	audio.play_sfx("coin", 0.8, -6.0)

func start_run() -> void:
	run_active = true
	wave = 1
	coins = GameData.START_COINS
	score = 0
	wall_hp = GameData.WALL_MAX
	upgrades = {"damage": 0, "multishot": 0, "quickdraw": 0, "pierce": 0}
	repair_count = 0
	kills = 0
	shots_fired = 0
	hint_seen = false
	dawn = 0.0
	new_best = false
	next_enemy_id = 1
	_start_wave()

func _start_wave() -> void:
	state = State.PLAYING
	previous_state = State.PLAYING
	wave_elapsed = 0.0
	spawned_count = 0
	spawn_queue = Levels.build(wave)
	enemies.clear()
	arrows.clear()
	rocks.clear()
	effects.clear()
	wave_cleared = false
	shop_timer = -1.0
	victory_timer = -1.0
	defeat_timer = -1.0
	boss_active = false
	boss_hp = 0.0
	boss_max_hp = 0.0
	aiming = false
	aim_preview.clear()
	cooldown = 0.0
	recoil = 0.0
	best_wave = maxi(best_wave, wave)
	ui.show_hud()
	ui.show_banner(
		I18n.t(language, "wave_banner", {"n": "%02d" % wave}),
		Levels.title(wave, language),
		"NIGHT %02d" % wave
	)
	audio.play_sfx("horn", 0.95, -5.0)

func next_wave() -> void:
	if state != State.SHOP:
		return
	if wave >= GameData.TOTAL_WAVES:
		return
	wave += 1
	best_wave = maxi(best_wave, wave)
	_start_wave()

func pause_game() -> void:
	if state != State.PLAYING or defeat_timer >= 0.0 or shop_timer >= 0.0 or victory_timer >= 0.0:
		return
	previous_state = state
	state = State.PAUSED
	aiming = false
	aim_preview.clear()
	ui.show_pause()
	audio.play_sfx("click", 1.0, -6.0)

func resume_game() -> void:
	if state != State.PAUSED:
		return
	state = previous_state
	ui.hide_overlays()
	ui.show_hud()
	audio.play_sfx("click", 1.0, -6.0)

func restart_run() -> void:
	_record_progress()
	start_run()

func quit_to_menu() -> void:
	_record_progress()
	state = State.MENU
	run_active = false
	aiming = false
	aim_preview.clear()
	enemies.clear()
	arrows.clear()
	rocks.clear()
	effects.clear()
	boss_active = false
	dawn = 0.0
	wall_hp = GameData.WALL_MAX
	wave = 1
	ui.show_menu()
	audio.play_sfx("click", 1.0, -6.0)

func show_tutorial(start_after: bool = false) -> void:
	state = State.TUTORIAL
	tutorial_page = 0
	tutorial_start_after = start_after
	aiming = false
	ui.show_tutorial()
	audio.play_sfx("click", 1.0, -6.0)

func tutorial_next() -> void:
	tutorial_page += 1
	if tutorial_page > 2:
		finish_tutorial()
	else:
		ui.refresh_tutorial()
		audio.play_sfx("click", 1.0, -8.0)

func tutorial_back() -> void:
	tutorial_page = maxi(0, tutorial_page - 1)
	ui.refresh_tutorial()
	audio.play_sfx("click", 0.92, -8.0)

func finish_tutorial() -> void:
	save_data["tutorial_seen"] = true
	save_data["language"] = language
	save_data["sound"] = sound_on
	SaveGame.store(save_data)
	if tutorial_start_after:
		start_run()
	else:
		quit_to_menu()

func close_tutorial() -> void:
	quit_to_menu()

func play_pressed() -> void:
	if bool(save_data.get("tutorial_seen", false)):
		start_run()
	else:
		show_tutorial(true)

func toggle_language() -> void:
	language = "en" if language == "ar" else "ar"
	save_data["language"] = language
	save_data["sound"] = sound_on
	SaveGame.store(save_data)
	ui.refresh_language()
	ui.refresh_tutorial()
	ui.refresh_shop()
	audio.play_sfx("click", 1.0, -6.0)

func toggle_sound() -> void:
	sound_on = not sound_on
	save_data["sound"] = sound_on
	save_data["language"] = language
	SaveGame.store(save_data)
	audio.set_enabled(sound_on)
	ui.refresh_language()
	audio.play_sfx("click", 1.0, -6.0)

func buy_upgrade(id: String) -> void:
	if state != State.SHOP:
		return
	var level := int(upgrades.get(id, 0))
	if not Upgrades.DEFS.has(id):
		return
	var max_level := int(Upgrades.DEFS[id]["max"])
	if level >= max_level:
		return
	var price := Upgrades.cost(id, level)
	if coins < price:
		audio.play_sfx("hit", 0.7, -10.0)
		ui.flash_shop_coins()
		return
	coins -= price
	upgrades[id] = level + 1
	audio.play_sfx("coin", 1.08, -2.0)
	ui.refresh_shop()
	ui.flash_shop_coins()

func repair_wall() -> void:
	if state != State.SHOP:
		return
	if wall_hp >= GameData.WALL_MAX:
		return
	var price := Upgrades.repair_cost(repair_count)
	if coins < price:
		audio.play_sfx("hit", 0.7, -10.0)
		ui.flash_shop_coins()
		return
	coins -= price
	wall_hp = minf(GameData.WALL_MAX, wall_hp + Upgrades.REPAIR_AMOUNT)
	repair_count += 1
	audio.play_sfx("coin", 0.92, -2.0)
	ui.refresh_shop()
	ui.flash_shop_coins()

func _record_progress() -> void:
	var previous_best := int(save_data.get("high_score", 0))
	if score > previous_best:
		new_best = true
	high_score = maxi(high_score, score)
	best_wave = maxi(best_wave, wave)
	save_data["high_score"] = high_score
	save_data["best_wave"] = best_wave
	save_data["language"] = language
	save_data["sound"] = sound_on
	SaveGame.store(save_data)

func _living_enemy_count() -> int:
	var count := 0
	for e in enemies:
		if str(e["state"]) != "dead":
			count += 1
	return count

func _simulate_aim(from: Vector2, direction: Vector2, speed: float) -> Array:
	var points: Array = []
	var pos := from
	var vel := direction * speed
	var step := 0.03
	for i in 80:
		points.append(pos)
		vel.y += GameData.GRAVITY * step
		pos += vel * step
		if pos.y >= GameData.GROUND_Y or pos.x > viewport_size.x + 30.0 or pos.x < 0.0:
			break
	return points

func _screen_to_world(screen_pos: Vector2) -> Vector2:
	return Vector2(screen_pos.x, screen_pos.y - stage_offset)

func _aim_begin(screen_pos: Vector2) -> void:
	if state != State.PLAYING or defeat_timer >= 0.0 or shop_timer >= 0.0 or victory_timer >= 0.0:
		return
	var p := _screen_to_world(screen_pos)
	if p.y < 64.0 or p.y > GameData.GROUND_Y + 40.0 or p.x < 8.0:
		return
	if cooldown > 0.0:
		return
	aim_start = p
	aim_current = p
	aiming = true
	aim_power = 0.0
	aim_preview.clear()

func _aim_update(screen_pos: Vector2) -> void:
	if not aiming:
		return
	aim_current = _screen_to_world(screen_pos)
	var drag := aim_start - aim_current
	var pull := drag.length()
	if pull < GameData.MIN_PULL:
		aim_power = 0.0
		aim_preview.clear()
		return
	var angle := clampf(atan2(drag.y, drag.x), deg_to_rad(-82.0), deg_to_rad(14.0))
	aim_dir = Vector2.from_angle(angle)
	aim_power = clampf((pull - GameData.MIN_PULL) / (GameData.MAX_PULL - GameData.MIN_PULL), 0.0, 1.0)
	aim_speed = lerpf(GameData.MIN_SHOT_SPEED, GameData.MAX_SHOT_SPEED, aim_power)
	aim_preview = _simulate_aim(GameData.BOW_POS, aim_dir, aim_speed)

func _aim_release(screen_pos: Vector2) -> void:
	if not aiming:
		return
	_aim_update(screen_pos)
	aiming = false
	if aim_power > 0.02 and cooldown <= 0.0:
		_fire_arrow()
	aim_preview.clear()

func _fire_arrow() -> void:
	if state != State.PLAYING:
		return
	var extra := Upgrades.extra_arrows(int(upgrades["multishot"]))
	var count := 1 + extra
	var spread := 4.2
	var base_damage := GameData.BASE_DAMAGE * Upgrades.damage_multiplier(int(upgrades["damage"]))
	for i in count:
		var offset := 0.0
		if count > 1:
			offset = deg_to_rad(spread * (float(i) - float(count - 1) * 0.5))
		var dir := aim_dir.rotated(offset)
		arrows.append({
			"pos": GameData.BOW_POS,
			"prev": GameData.BOW_POS,
			"vel": dir * aim_speed,
			"damage": base_damage,
			"hits_left": Upgrades.pierce_hits(int(upgrades["pierce"])),
			"hits": [],
			"life": 0.0,
			"trail": [GameData.BOW_POS],
			"dead": false
		})
	cooldown = GameData.BASE_COOLDOWN * Upgrades.cooldown_multiplier(int(upgrades["quickdraw"]))
	recoil = 1.0
	shots_fired += 1
	hint_seen = true
	shake = maxf(shake, 1.4)
	audio.play_sfx("bow", randf_range(0.96, 1.05), -2.0)
	_burst(GameData.BOW_POS, Color("#ffc857"), 4, 45.0)

func _add_effect_text(pos: Vector2, text: String, color: Color, font_size: int, life: float) -> void:
	effects.append({
		"kind": "text", "pos": pos, "text": text, "color": color,
		"font_size": font_size, "life": life, "max_life": life
	})

func _burst(pos: Vector2, color: Color, count: int, speed: float) -> void:
	for i in count:
		var angle := randf_range(-PI, 0.0)
		var magnitude := randf_range(speed * 0.3, speed)
		effects.append({
			"kind": "spark", "pos": pos,
			"vel": Vector2(cos(angle), sin(angle)) * magnitude,
			"color": color, "size": randf_range(1.4, 3.5),
			"life": randf_range(0.28, 0.62), "max_life": 0.62,
			"gravity": 260.0
		})

func _add_coin_burst(pos: Vector2, amount: int) -> void:
	var count := clampi(amount, 2, 6)
	for i in count:
		effects.append({
			"kind": "coin", "pos": pos + Vector2(randf_range(-14.0, 14.0), randf_range(-8.0, 8.0)),
			"vel": Vector2(randf_range(-45.0, 45.0), randf_range(-150.0, -80.0)),
			"life": randf_range(0.45, 0.8), "max_life": 0.8, "gravity": 240.0
		})

func _add_ring(pos: Vector2, color: Color, radius: float) -> void:
	effects.append({
		"kind": "ring", "pos": pos, "color": color,
		"radius": radius, "life": 0.42, "max_life": 0.42
	})

func _add_stuck_arrow(pos: Vector2, angle: float) -> void:
	effects.append({
		"kind": "stuck", "pos": pos, "angle": angle,
		"life": 2.5, "max_life": 2.5
	})

func _update_effects(delta: float) -> void:
	var kept: Array = []
	for e in effects:
		e["life"] = float(e["life"]) - delta
		if float(e["life"]) <= 0.0:
			continue
		if e.has("vel"):
			e["vel"] = Vector2(e["vel"]) + Vector2(0.0, float(e.get("gravity", 0.0))) * delta
			e["pos"] = Vector2(e["pos"]) + Vector2(e["vel"]) * delta
		elif str(e["kind"]) == "text":
			e["pos"] = Vector2(e["pos"]) + Vector2(0.0, -28.0) * delta
		kept.append(e)
	effects = kept

func get_wall_ratio() -> float:
	return clampf(wall_hp / GameData.WALL_MAX, 0.0, 1.0)

func get_boss_ratio() -> float:
	if boss_max_hp <= 0.0:
		return 0.0
	return clampf(boss_hp / boss_max_hp, 0.0, 1.0)

func get_next_wave_title() -> String:
	var next := mini(wave + 1, GameData.TOTAL_WAVES)
	return Levels.title(next, language)

func is_playing() -> bool:
	return state == State.PLAYING and defeat_timer < 0.0 and shop_timer < 0.0 and victory_timer < 0.0

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed:
			_aim_begin(event.position)
		else:
			_aim_release(event.position)
		get_viewport().set_input_as_handled()
		return
	if event is InputEventScreenDrag:
		_aim_update(event.position)
		get_viewport().set_input_as_handled()
		return
	if OS.has_feature("mobile"):
		return
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if event.pressed:
			_aim_begin(event.position)
		else:
			_aim_release(event.position)
		get_viewport().set_input_as_handled()
	elif event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
		_aim_update(event.position)
	elif event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_ESCAPE:
			if state == State.PLAYING:
				pause_game()
			elif state == State.PAUSED:
				resume_game()
			get_viewport().set_input_as_handled()
