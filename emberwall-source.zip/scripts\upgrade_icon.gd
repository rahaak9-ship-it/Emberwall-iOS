class_name UpgradeIcon
extends Control

var mode := "damage"

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _draw() -> void:
	var cx := size.x * 0.5
	var cy := size.y * 0.5
	var accent := Color("#ff7a2f")
	if Upgrades.DEFS.has(mode):
		accent = Color(str(Upgrades.DEFS[mode]["accent"]))
	match mode:
		"damage":
			draw_line(Vector2(cx - 28, cy + 11), Vector2(cx + 22, cy - 8), accent, 2.2, true)
			draw_colored_polygon(PackedVector2Array([
				Vector2(cx + 30, cy - 11), Vector2(cx + 21, cy - 8), Vector2(cx + 25, cy - 1)
			]), Color("#ffc857"))
			draw_line(Vector2(cx - 22, cy + 4), Vector2(cx - 18, cy - 6), Color(accent.r, accent.g, accent.b, 0.55), 1.4, true)
			draw_line(Vector2(cx - 14, cy + 7), Vector2(cx - 10, cy - 3), Color(accent.r, accent.g, accent.b, 0.45), 1.2, true)
		"multishot":
			for i in 3:
				var a := -0.17 + float(i) * 0.17
				var start := Vector2(cx - 28, cy + 10)
				var end := start + Vector2(cos(a), sin(a)) * 50.0
				draw_line(start, end, Color(accent.r, accent.g, accent.b, 0.75), 1.7, true)
				draw_colored_polygon(PackedVector2Array([
					end + Vector2(6, 0), end + Vector2(-3, -3), end + Vector2(-3, 3)
				]), Color("#ffc857"))
		"quickdraw":
			draw_arc(Vector2(cx, cy), 20.0, 0.0, TAU, 26, Color(accent.r, accent.g, accent.b, 0.8), 2.0, true)
			draw_arc(Vector2(cx, cy), 20.0, -1.57, -0.15, 14, Color("#ffc857"), 2.4, true)
			draw_line(Vector2(cx, cy), Vector2(cx + 13, cy - 5), Color("#f3ead9"), 1.5, true)
			draw_line(Vector2(cx - 30, cy - 20), Vector2(cx - 22, cy - 20), Color(0.85, 0.82, 0.75, 0.3), 1.2)
			draw_line(Vector2(cx + 23, cy - 20), Vector2(cx + 31, cy - 20), Color(0.85, 0.82, 0.75, 0.3), 1.2)
		"pierce":
			draw_line(Vector2(cx - 32, cy), Vector2(cx + 28, cy), Color(accent.r, accent.g, accent.b, 0.8), 2.0, true)
			draw_colored_polygon(PackedVector2Array([
				Vector2(cx + 36, cy), Vector2(cx + 26, cy - 4), Vector2(cx + 26, cy + 4)
			]), Color("#f3ead9"))
			draw_line(Vector2(cx - 10, cy - 13), Vector2(cx - 10, cy + 13), Color(accent.r, accent.g, accent.b, 0.45), 1.5)
			draw_line(Vector2(cx + 8, cy - 13), Vector2(cx + 8, cy + 13), Color(accent.r, accent.g, accent.b, 0.30), 1.5)
		"repair":
			var base := Vector2(cx, cy + 6)
			draw_rect(Rect2(base.x - 30, base.y, 60, 14), Color(accent.r, accent.g, accent.b, 0.28))
			for i in 4:
				draw_rect(Rect2(base.x - 30 + float(i) * 15, base.y - 7, 10, 7), Color(accent.r, accent.g, accent.b, 0.30))
			draw_line(Vector2(base.x - 30, base.y + 6), Vector2(base.x + 30, base.y + 6), Color(accent.r, accent.g, accent.b, 0.55), 1.0)
			draw_line(Vector2(base.x - 8, base.y - 15), Vector2(base.x + 8, base.y - 15), Color("#ffc857"), 3.0, true)
			draw_line(Vector2(base.x, base.y - 23), Vector2(base.x, base.y - 7), Color("#ffc857"), 3.0, true)
