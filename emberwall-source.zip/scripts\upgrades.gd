class_name Upgrades
extends RefCounted

const DEFS := {
	"damage": {
		"max": 5,
		"costs": [16, 26, 40, 60, 90],
		"en": "SHARPENED ARROWS",
		"ar": "سهام أحدّ",
		"desc_en": "+22% arrow damage",
		"desc_ar": "+22% ضرر للسهم",
		"accent": "#ff7a2f"
	},
	"multishot": {
		"max": 2,
		"costs": [50, 110],
		"en": "SPLIT SHOT",
		"ar": "سهم مشقوق",
		"desc_en": "+1 arrow per shot",
		"desc_ar": "+1 سهم في كل طلقة",
		"accent": "#ffc857"
	},
	"quickdraw": {
		"max": 4,
		"costs": [18, 30, 48, 70],
		"en": "QUICK DRAW",
		"ar": "سحب أسرع",
		"desc_en": "-13% draw time",
		"desc_ar": "-13% زمن التجهيز",
		"accent": "#55c7b4"
	},
	"pierce": {
		"max": 2,
		"costs": [45, 100],
		"en": "PIERCING TIP",
		"ar": "سهم نافذ",
		"desc_en": "+1 enemy pierced",
		"desc_ar": "يخترق عدواً إضافياً",
		"accent": "#9c8cff"
	}
}

const REPAIR_COST_BASE := 18
const REPAIR_COST_STEP := 6
const REPAIR_AMOUNT := 30.0

static func damage_multiplier(level: int) -> float:
	return 1.0 + 0.22 * float(level)

static func cooldown_multiplier(level: int) -> float:
	return maxf(0.48, 1.0 - 0.13 * float(level))

static func pierce_hits(level: int) -> int:
	return 1 + level

static func extra_arrows(level: int) -> int:
	return level

static func repair_cost(times_repaired: int) -> int:
	return REPAIR_COST_BASE + times_repaired * REPAIR_COST_STEP

static func cost(id: String, level: int) -> int:
	if not DEFS.has(id):
		return 0
	var costs: Array = DEFS[id]["costs"]
	if level < 0 or level >= costs.size():
		return 0
	return int(costs[level])

static func name_for(id: String, language: String) -> String:
	if not DEFS.has(id):
		return id
	var d: Dictionary = DEFS[id]
	return str(d.get(language, d["en"]))

static func desc_for(id: String, language: String) -> String:
	if not DEFS.has(id):
		return ""
	var d: Dictionary = DEFS[id]
	if language == "ar":
		return str(d.get("desc_ar", d["desc_en"]))
	return str(d.get("desc_en", ""))
