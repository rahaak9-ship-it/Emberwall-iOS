#!/usr/bin/env bash
# Archives the generated Xcode project. Codemagic has installed the signing
# certificate and provisioning profile for $EMBERWALL_BUNDLE_ID.
set -euo pipefail

ROOT="${CM_BUILD_DIR:?CM_BUILD_DIR is required}"
cd "$ROOT"
test -n "${APPLE_TEAM_ID:-}"
test -n "${EMBERWALL_BUNDLE_ID:-}"

xcodebuild \
  -project build/ios/Emberwall.xcodeproj \
  -scheme Emberwall \
  -configuration Release \
  -sdk iphoneos \
  -archivePath build/Emberwall.xcarchive \
  archive \
  CODE_SIGN_STYLE=Automatic \
  DEVELOPMENT_TEAM="$APPLE_TEAM_ID" \
  PRODUCT_BUNDLE_IDENTIFIER="$EMBERWALL_BUNDLE_ID" \
  -allowProvisioningUpdates \
  2>&1 | tee build/xcodebuild-archive.log
test -d build/Emberwall.xcarchive
