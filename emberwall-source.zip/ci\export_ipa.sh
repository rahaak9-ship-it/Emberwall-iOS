#!/usr/bin/env bash
# Exports a signed App Store IPA from the archive.
set -euo pipefail

ROOT="${CM_BUILD_DIR:?CM_BUILD_DIR is required}"
cd "$ROOT"
test -n "${APPLE_TEAM_ID:-}"

cat > build/ExportOptions.plist <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>method</key>
  <string>app-store</string>
  <key>signingStyle</key>
  <string>automatic</string>
  <key>teamID</key>
  <string>${APPLE_TEAM_ID}</string>
  <key>stripSwiftSymbols</key>
  <true/>
  <key>uploadSymbols</key>
  <false/>
</dict>
</plist>
PLIST

mkdir -p build/ipa
xcodebuild \
  -exportArchive \
  -archivePath build/Emberwall.xcarchive \
  -exportOptionsPlist build/ExportOptions.plist \
  -exportPath build/ipa \
  -allowProvisioningUpdates \
  2>&1 | tee build/xcodebuild-export.log
ls -lh build/ipa
