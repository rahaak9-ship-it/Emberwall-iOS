extends SceneTree

var main: Node
var shots := 0
var total_time := 0.0

func _init() -> void:
	call_deferred("_run")

func _run() -> void:
	SaveGame.path = "user://emberwall.playthrough-test.save"
	if FileAccess.file_exists(SaveGame.path):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(SaveGame.path))
	main = load("res://scenes/main.tscn").instantiate()
	root.add_child(main)
	await process_frame
	await process_frame
	if main.audio:
		main.audio.set_enabled(false)
	main.set_process(false)
	main.start_run()
	await process_frame

	var failed := false
	for wave in range(1, 13):
		var wave_start_wall := float(main.wall_hp)
		var elapsed := 0.0
		while elapsed < 95.0:
			if main.wall_hp <= 0.0 or main.defeat_timer >= 0.0:
				break
			main.cooldown = maxf(0.0, float(main.cooldown) - 1.0 / 60.0)
			if main.cooldown <= 0.0 and main.state == main.State.PLAYING:
				var target := _choose_target()
				if not target.is_empty():
					_shoot(target)
			main._update_playing(1.0 / 60.0)
			elapsed += 1.0 / 60.0
			total_time += 1.0 / 60.0
			if main.shop_timer > 0.0 or main.victory_timer > 0.0:
				break
			if main.state != main.State.PLAYING:
				break
		if main.wall_hp <= 0.0 or main.defeat_timer >= 0.0:
			print("WAVE %02d DEFEAT wall=%.0f t=%.1f" % [wave, main.wall_hp, elapsed])
			failed = true
			break
		if main.victory_timer > 0.0:
			print("WAVE %02d CLEAR wall=%.0f/%.0f coins=%d score=%d t=%.1f" % [wave, main.wall_hp, wave_start_wall, main.coins, main.score, elapsed])
			main._finish_victory()
			break
		if main.shop_timer > 0.0:
			print("WAVE %02d CLEAR wall=%.0f/%.0f coins=%d score=%d t=%.1f" % [wave, main.wall_hp, wave_start_wall, main.coins, main.score, elapsed])
			main._open_shop()
			_spend()
			main.next_wave()
			continue
		print("WAVE %02d STUCK wall=%.0f enemies=%d spawned=%d/%d t=%.1f" % [wave, main.wall_hp, main.enemies.size(), main.spawned_count, main.spawn_queue.size(), elapsed])
		failed = true
		break

	print("PLAYTHROUGH state=%s wave=%d wall=%.0f score=%d shots=%d upgrades=%s" % [str(main.state), main.wave, main.wall_hp, main.score, shots, str(main.upgrades)])
	var success: bool = not failed and main.state == main.State.VICTORY
	print("PLAYTHROUGH_RESULT %s" % ("PASS" if success else "FAIL"))
	main.queue_free()
	await process_frame
	if FileAccess.file_exists(SaveGame.path):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(SaveGame.path))
	quit(0 if success else 1)

func _choose_target() -> Dictionary:
	var best: Dictionary = {}
	var best_x := INF
	for e in main.enemies:
		if str(e["state"]) == "dead":
			continue
		var x := float(e["x"])
		if x < best_x:
			best_x = x
			best = e
	return best

func _shoot(enemy: Dictionary) -> void:
	var h := float(enemy["height"])
	var dx := float(enemy["x"]) - GameData.BOW_POS.x
	var flight := clampf(dx / 680.0, 0.42, 1.15)
	var lead := float(enemy["speed"]) * flight
	var target := Vector2(float(enemy["x"]) - lead, GameData.GROUND_Y - h * 0.88)
	target.x = maxf(target.x, GameData.WALL_X + 24.0)
	dx = target.x - GameData.BOW_POS.x
	var dy := target.y - GameData.BOW_POS.y
	var vx := dx / flight
	var vy := (dy - 0.5 * GameData.GRAVITY * flight * flight) / flight
	main.aim_dir = Vector2(vx, vy).normalized()
	main.aim_speed = Vector2(vx, vy).length()
	main.aiming = true
	main.aim_power = 1.0
	main.cooldown = 0.0
	main._fire_arrow()
	main.aiming = false
	shots += 1

func _spend() -> void:
	while true:
		if float(main.wall_hp) < 55.0:
			var rcost: int = Upgrades.repair_cost(int(main.repair_count))
			if int(main.coins) >= rcost:
				main.repair_wall()
				continue
		var bought := false
		for id in ["damage", "quickdraw", "multishot", "pierce"]:
			var level := int(main.upgrades[id])
			var max_level := int(Upgrades.DEFS[id]["max"])
			if level >= max_level:
				continue
			if id == "damage" and level >= 3 and int(main.upgrades["multishot"]) < 1:
				continue
			var price := Upgrades.cost(id, level)
			if int(main.coins) >= price:
				main.buy_upgrade(id)
				bought = true
				break
		if not bought:
			break
	print("  SHOP coins=%d wall=%.0f upgrades=%s" % [main.coins, main.wall_hp, str(main.upgrades)])
