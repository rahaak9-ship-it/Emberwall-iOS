class_name WorldView
extends Node2D

var main: Node
var time := 0.0
var vp := Vector2(840, 480)
var stage_y := 0.0
var stars: Array = []
var embers: Array = []
var font: Font

func _ready() -> void:
	_seed_decor()
	var loaded: Variant = load("res://assets/fonts/NotoSansArabic-Variable.ttf")
	if loaded is Font:
		font = loaded
	else:
		font = ThemeDB.fallback_font
	set_process(true)

func _seed_decor() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 20261026
	for i in 95:
		stars.append({
			"x": rng.randf(),
			"y": rng.randf_range(0.02, 0.72),
			"r": rng.randf_range(0.6, 1.9),
			"phase": rng.randf_range(0.0, TAU),
			"speed": rng.randf_range(0.3, 1.1)
		})
	for i in 30:
		embers.append({
			"x": rng.randf_range(0.02, 0.98),
			"phase": rng.randf_range(0.0, 1.0),
			"speed": rng.randf_range(0.018, 0.055),
			"size": rng.randf_range(0.7, 2.0),
			"drift": rng.randf_range(0.2, 1.0)
		})

func _process(delta: float) -> void:
	time += delta
	vp = get_viewport_rect().size
	stage_y = GameData.stage_offset_y(vp.y)
	queue_redraw()

func _draw() -> void:
	_draw_sky()
	_draw_moon_and_sun()
	_draw_stars()
	_draw_clouds()
	_draw_mountains()
	_draw_forest()
	_draw_horizon_fog()

	var shake_offset := Vector2.ZERO
	if main and main.shake > 0.05:
		shake_offset.x = sin(time * 97.0) * main.shake * 0.55
		shake_offset.y = cos(time * 81.0) * main.shake * 0.38
	draw_set_transform(Vector2(shake_offset.x, stage_y + shake_offset.y), 0.0, Vector2.ONE)

	_draw_ground()
	_draw_wall()
	_draw_archer()
	if main:
		_draw_enemies()
		_draw_rocks()
		_draw_arrows()
		_draw_aim()
		_draw_effects()
	_draw_foreground()
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	_draw_ambient_embers()

func _sky_pair(t: float) -> Color:
	var top := Color("#050817")
	var mid := Color("#141d3d")
	var low := Color("#4a4460")
	var c: Color
	if t < 0.55:
		c = top.lerp(mid, t / 0.55)
	else:
		c = mid.lerp(low, (t - 0.55) / 0.45)
	if main and main.dawn > 0.0:
		var d_top := Color("#29365d")
		var d_mid := Color("#8f5c67")
		var d_low := Color("#ffb06e")
		var dc: Color
		if t < 0.55:
			dc = d_top.lerp(d_mid, t / 0.55)
		else:
			dc = d_mid.lerp(d_low, (t - 0.55) / 0.45)
		c = c.lerp(dc, clampf(main.dawn, 0.0, 1.0))
	return c

func _draw_sky() -> void:
	var bands := 34
	for i in bands:
		var t := float(i) / float(bands - 1)
		var color := _sky_pair(t)
		var y0 := vp.y * float(i) / float(bands)
		var y1 := vp.y * float(i + 1) / float(bands) + 1.0
		draw_rect(Rect2(0, y0, vp.x, y1 - y0), color)
	var glow: Color = Color(1.0, 0.62, 0.35, 0.06 + 0.10 * (main.dawn if main else 0.0))
	draw_circle(Vector2(vp.x * 0.78, stage_y + GameData.GROUND_Y), vp.x * 0.55, glow)

func _draw_moon_and_sun() -> void:
	var moon_pos := Vector2(vp.x * 0.87, stage_y + 62.0)
	var moon_alpha: float = 1.0 - (main.dawn if main else 0.0) * 0.9
	if moon_alpha > 0.02:
		for i in range(6, 0, -1):
			var r := 40.0 + float(i) * 12.0
			draw_circle(moon_pos, r, Color(1.0, 0.91, 0.72, 0.014 * float(i)))
		draw_circle(moon_pos, 36.0, Color(0.96, 0.90, 0.76, moon_alpha))
		draw_circle(moon_pos + Vector2(8, -7), 6.5, Color(0.86, 0.79, 0.64, 0.45 * moon_alpha))
		draw_circle(moon_pos + Vector2(-12, 11), 9.0, Color(0.88, 0.81, 0.67, 0.35 * moon_alpha))
		draw_circle(moon_pos + Vector2(6, 13), 3.5, Color(0.88, 0.81, 0.67, 0.35 * moon_alpha))
	if main and main.dawn > 0.01:
		var alpha: float = clampf(main.dawn, 0.0, 1.0)
		var sun_pos := Vector2(vp.x * 0.76, stage_y + GameData.GROUND_Y - 22.0 - 45.0 * main.dawn)
		for i in range(8, 0, -1):
			draw_circle(sun_pos, 50.0 + i * 28.0, Color(1.0, 0.66, 0.35, 0.014 * i * alpha))
		draw_circle(sun_pos, 44.0, Color(1.0, 0.82, 0.54, alpha))

func _draw_stars() -> void:
	if main and main.dawn > 0.8:
		return
	var alpha_mul: float = 1.0 - (main.dawn if main else 0.0)
	for s in stars:
		var x := float(s["x"]) * vp.x
		var y := float(s["y"]) * (stage_y + 390.0)
		var twinkle := 0.55 + 0.45 * sin(time * float(s["speed"]) * 2.1 + float(s["phase"]))
		var alpha: float = twinkle * alpha_mul
		draw_circle(Vector2(x, y), float(s["r"]), Color(0.95, 0.90, 0.78, alpha))
		if float(s["r"]) > 1.5:
			draw_circle(Vector2(x, y), float(s["r"]) * 3.0, Color(0.95, 0.90, 0.78, alpha * 0.08))

func _draw_clouds() -> void:
	var drift := time * 2.3
	var clouds := [
		{"x": 0.08, "y": 0.23, "w": 220.0, "a": 0.20},
		{"x": 0.62, "y": 0.33, "w": 300.0, "a": 0.13},
		{"x": 0.35, "y": 0.16, "w": 170.0, "a": 0.10}
	]
	for c in clouds:
		var x := fposmod(float(c["x"]) * vp.x + drift, vp.x + 460.0) - 230.0
		var y := stage_y + float(c["y"]) * 330.0
		var w := float(c["w"])
		var col := Color(0.03, 0.05, 0.12, float(c["a"]))
		_ellipse(Vector2(x, y), w, w * 0.13, col, 24)
		_ellipse(Vector2(x + w * 0.3, y - w * 0.06), w * 0.6, w * 0.16, col, 22)
		_ellipse(Vector2(x - w * 0.28, y + w * 0.03), w * 0.5, w * 0.11, col, 20)

func _draw_mountains() -> void:
	var horizon := stage_y + GameData.GROUND_Y
	var layers := [
		{"base": 32.0, "color": Color("#131a34"), "peaks": [0.0, 0.12, 0.27, 0.44, 0.60, 0.78, 0.92, 1.0], "heights": [34.0, 118.0, 66.0, 146.0, 76.0, 124.0, 54.0, 88.0]},
		{"base": 16.0, "color": Color("#0d1429"), "peaks": [0.0, 0.18, 0.34, 0.52, 0.69, 0.85, 1.0], "heights": [24.0, 82.0, 46.0, 98.0, 40.0, 86.0, 30.0]},
		{"base": 4.0, "color": Color("#080d1c"), "peaks": [0.0, 0.20, 0.38, 0.55, 0.72, 0.90, 1.0], "heights": [12.0, 46.0, 24.0, 58.0, 20.0, 42.0, 14.0]}
	]
	for layer in layers:
		var base := float(layer["base"])
		var color: Color = layer["color"]
		var peaks: Array = layer["peaks"]
		var heights: Array = layer["heights"]
		var points := PackedVector2Array()
		points.append(Vector2(0, horizon - base - float(heights[0])))
		for i in peaks.size():
			points.append(Vector2(float(peaks[i]) * vp.x, horizon - base - float(heights[i])))
		points.append(Vector2(vp.x, horizon - base - float(heights[heights.size() - 1])))
		points.append(Vector2(vp.x, horizon + 2.0))
		points.append(Vector2(0, horizon + 2.0))
		draw_colored_polygon(points, color)
		var ridge := PackedVector2Array()
		for p in points:
			if p.y < horizon - base + 1.0:
				ridge.append(p)
		if ridge.size() > 2:
			draw_polyline(ridge, Color(1.0, 0.76, 0.48, 0.045), 1.0, true)
	# a distant watchtower on the middle ridge
	var tx := vp.x * 0.74
	var ty := horizon - 100.0
	draw_rect(Rect2(tx, ty, 13.0, 54.0), Color("#080d1b"))
	draw_rect(Rect2(tx - 4.0, ty - 9.0, 22.0, 10.0), Color("#080d1b"))
	draw_colored_polygon(PackedVector2Array([Vector2(tx - 5, ty - 9), Vector2(tx + 6, ty - 25), Vector2(tx + 18, ty - 9)]), Color("#080d1b"))

func _draw_forest() -> void:
	var base := stage_y + GameData.GROUND_Y - 4.0
	var x := -10.0
	var i := 0
	while x < vp.x + 20.0:
		var h := 18.0 + fposmod(sin(x * 1.71 + 2.0) * 37.0, 1.0) * 32.0
		var w := 12.0 + fposmod(sin(x * 0.93) * 13.0, 1.0) * 10.0
		draw_colored_polygon(PackedVector2Array([
			Vector2(x - w, base), Vector2(x, base - h), Vector2(x + w, base)
		]), Color("#070c19"))
		x += 19.0 + fposmod(sin(float(i) * 4.7) * 11.0, 1.0) * 12.0
		i += 1

func _draw_horizon_fog() -> void:
	draw_rect(Rect2(0, stage_y + 370.0, vp.x, 56.0), Color(0.55, 0.57, 0.70, 0.025))
	draw_rect(Rect2(0, stage_y + 392.0, vp.x, 30.0), Color(0.65, 0.62, 0.72, 0.022))

func _draw_ground() -> void:
	var top := GameData.GROUND_Y
	draw_rect(Rect2(0, top, vp.x + 10.0, 78.0), Color("#0b0f1e"))
	draw_rect(Rect2(0, top, vp.x + 10.0, 4.0), Color("#242c49"))
	draw_rect(Rect2(0, top + 4.0, vp.x + 10.0, 7.0), Color(0.10, 0.12, 0.20, 0.7))
	for i in 26:
		var x := fposmod(sin(float(i) * 13.71) * 41.0, 1.0) * vp.x
		var y := top + 12.0 + fposmod(sin(float(i) * 7.13) * 9.0, 1.0) * 48.0
		var r := 1.0 + fposmod(sin(float(i) * 3.31) * 7.0, 1.0) * 2.4
		draw_circle(Vector2(x, y), r, Color(0.16, 0.18, 0.29, 0.55))
	var path_y := top + 43.0
	draw_line(Vector2(180, path_y), Vector2(vp.x, path_y - 12.0), Color(0.16, 0.13, 0.18, 0.45), 2.0)
	draw_line(Vector2(180, path_y + 3.0), Vector2(vp.x, path_y - 9.0), Color(0.12, 0.10, 0.15, 0.4), 1.0)

func _draw_wall() -> void:
	var wall_w := GameData.WALL_X
	var top := GameData.WALL_TOP
	var bottom := GameData.GROUND_Y + 8.0
	draw_rect(Rect2(wall_w, top + 12.0, 120.0, 50.0), Color(0.02, 0.03, 0.07, 0.32))
	draw_rect(Rect2(0, top, wall_w, bottom - top), Color("#1b2442"))
	# crenellations
	for i in 4:
		var mx := float(i) * 39.0
		draw_rect(Rect2(mx, top - 18.0, 27.0, 19.0), Color("#202a4a"))
		draw_rect(Rect2(mx, top - 18.0, 27.0, 3.0), Color("#2f3a5e"))
		draw_rect(Rect2(mx + 3.0, top - 15.0, 2.0, 13.0), Color(0.06, 0.08, 0.16, 0.5))
	# stone courses
	var row_h := 26.0
	for row in 5:
		var y := top + float(row) * row_h
		draw_line(Vector2(0, y), Vector2(wall_w, y), Color(0.04, 0.06, 0.13, 0.8), 1.2)
		var offset := 0.0 if row % 2 == 0 else 19.0
		var x := offset
		while x < wall_w:
			var stone_w := 32.0 + fposmod(sin(x * 1.7 + float(row) * 3.1) * 9.0, 1.0) * 18.0
			var shade := 0.02 * sin(x * 0.31 + float(row))
			var color := Color(0.14 + shade, 0.18 + shade, 0.30 + shade, 1.0)
			draw_rect(Rect2(x + 1.0, y + 1.0, stone_w - 2.0, row_h - 2.0), color)
			if fposmod(sin(x + float(row)) * 11.0, 1.0) > 0.72:
				draw_rect(Rect2(x + 5.0, y + 5.0, stone_w * 0.35, 3.0), Color(0.26, 0.30, 0.45, 0.30))
			x += stone_w
	draw_rect(Rect2(0, top, wall_w, 2.0), Color("#3a4668"))
	draw_line(Vector2(wall_w, top), Vector2(wall_w, bottom), Color("#0a0e1d"), 3.0)
	# moss
	for i in 7:
		var mx := 8.0 + fposmod(sin(float(i) * 9.0) * 37.0, 1.0) * 130.0
		var my := top + 22.0 + fposmod(sin(float(i) * 3.7) * 11.0, 1.0) * 96.0
		draw_line(Vector2(mx, my), Vector2(mx + 4.0, my + 13.0), Color(0.18, 0.31, 0.25, 0.35), 1.5)
	# damage cracks
	var damage: float = clampf(1.0 - (main.wall_hp / GameData.WALL_MAX if main else 0.0), 0.0, 1.0)
	if damage > 0.05:
		var a := clampf(damage * 1.6, 0.0, 1.0)
		var cracks := [
			[Vector2(138, 304), Vector2(126, 326), Vector2(133, 342), Vector2(120, 366), Vector2(126, 388)],
			[Vector2(86, 350), Vector2(98, 366), Vector2(90, 382), Vector2(102, 402)],
			[Vector2(42, 306), Vector2(51, 318), Vector2(44, 336), Vector2(56, 350)],
			[Vector2(132, 408), Vector2(118, 422), Vector2(123, 438)]
		]
		for path in cracks:
			var pts := PackedVector2Array()
			for p in path:
				pts.append(p)
			draw_polyline(pts, Color(0.02, 0.03, 0.07, a), 2.0, true)
			draw_polyline(pts, Color(1.0, 0.46, 0.21, a * 0.09), 4.0, true)
	# torch
	var torch_pos := Vector2(36, 342)
	for i in range(6, 0, -1):
		draw_circle(torch_pos + Vector2(0, -8), 18.0 + i * 5.0, Color(1.0, 0.52, 0.18, 0.012 * i))
	draw_rect(Rect2(torch_pos.x - 2.5, torch_pos.y - 2.0, 5.0, 28.0), Color("#3d2a20"))
	var flick := sin(time * 12.0) * 2.0 + sin(time * 23.0) * 1.0
	draw_colored_polygon(PackedVector2Array([
		torch_pos + Vector2(-7, -3), torch_pos + Vector2(-2 + flick, -25),
		torch_pos + Vector2(5, -8), torch_pos + Vector2(1, -2)
	]), Color("#ff9b54"))
	draw_colored_polygon(PackedVector2Array([
		torch_pos + Vector2(-3, -6), torch_pos + Vector2(1 + flick * 0.4, -17),
		torch_pos + Vector2(4, -6)
	]), Color("#fff0b3"))
	# flag
	var pole := Vector2(116, 294)
	draw_line(pole, pole + Vector2(0, -100.0), Color("#1d2338"), 3.0)
	var wave := sin(time * 2.4) * 5.0
	var flag_pts := PackedVector2Array([
		pole + Vector2(1, -98),
		pole + Vector2(50, -94 + wave),
		pole + Vector2(54, -62 + wave * 0.5),
		pole + Vector2(1, -64)
	])
	draw_colored_polygon(flag_pts, Color("#d9572a"))
	draw_circle(pole + Vector2(27, -79 + wave * 0.4), 7.0, Color(1.0, 0.80, 0.46, 0.9))
	draw_colored_polygon(PackedVector2Array([
		pole + Vector2(27, -85 + wave * 0.4), pole + Vector2(32, -78 + wave * 0.4),
		pole + Vector2(27, -73 + wave * 0.4), pole + Vector2(22, -78 + wave * 0.4)
	]), Color("#ff7a2f"))

func _draw_archer() -> void:
	var feet := GameData.ARCHER_FEET
	var recoil_x: float = -(main.recoil * 4.0 if main else 0.0)
	var base := feet + Vector2(recoil_x, 0)
	_ellipse(base + Vector2(0, 2), 20.0, 4.5, Color(0.02, 0.03, 0.07, 0.55), 18)
	# legs
	var step := 0.0
	draw_line(base + Vector2(-7, -3), base + Vector2(-10, -22), Color("#0d1324"), 6.0, true)
	draw_line(base + Vector2(6, -3), base + Vector2(9, -20), Color("#0d1324"), 6.0, true)
	draw_line(base + Vector2(-14, -2), base + Vector2(-6, -2), Color("#202944"), 4.0, true)
	draw_line(base + Vector2(9, -2), base + Vector2(17, -2), Color("#202944"), 4.0, true)
	# cloak
	draw_colored_polygon(PackedVector2Array([
		base + Vector2(-17, -42), base + Vector2(-11, -64), base + Vector2(9, -65),
		base + Vector2(19, -46), base + Vector2(17, -8), base + Vector2(-15, -8)
	]), Color("#17213b"))
	# torso
	draw_colored_polygon(PackedVector2Array([
		base + Vector2(-11, -61), base + Vector2(8, -62), base + Vector2(12, -41),
		base + Vector2(8, -26), base + Vector2(-10, -27), base + Vector2(-13, -44)
	]), Color("#243354"))
	draw_line(base + Vector2(-9, -43), base + Vector2(10, -44), Color("#3b4a6e"), 1.2)
	# quiver
	draw_line(base + Vector2(12, -55), base + Vector2(23, -22), Color("#5b4128"), 5.0, true)
	draw_line(base + Vector2(18, -42), base + Vector2(23, -52), Color("#ffc857"), 1.5)
	draw_line(base + Vector2(21, -36), base + Vector2(26, -46), Color("#ffc857"), 1.5)
	# head and hood
	draw_circle(base + Vector2(-1, -74), 9.0, Color("#0b1022"))
	draw_colored_polygon(PackedVector2Array([
		base + Vector2(-12, -74), base + Vector2(-8, -86), base + Vector2(5, -88),
		base + Vector2(12, -78), base + Vector2(7, -70), base + Vector2(-7, -69)
	]), Color("#263353"))
	draw_colored_polygon(PackedVector2Array([
		base + Vector2(-13, -77), base + Vector2(-7, -70), base + Vector2(8, -69),
		base + Vector2(12, -74), base + Vector2(4, -78)
	]), Color("#11182e"))
	draw_circle(base + Vector2(6, -76), 1.2, Color(1.0, 0.72, 0.35, 0.8))
	# bow arm
	var bow_pivot := GameData.BOW_POS + Vector2(recoil_x, 0)
	draw_line(base + Vector2(5, -56), bow_pivot + Vector2(-2, -2), Color("#2a3553"), 5.0, true)
	draw_circle(bow_pivot + Vector2(-2, -2), 3.0, Color("#3a4667"))
	# bow
	var angle := -0.42
	var pull := 0.0
	if main and main.aiming:
		angle = atan2(main.aim_dir.y, main.aim_dir.x)
		pull = main.aim_power * 15.0
	draw_set_transform(bow_pivot, angle, Vector2.ONE)
	draw_arc(Vector2.ZERO, 24.0, -1.18, 1.18, 18, Color("#8b6741"), 3.0, true)
	draw_line(Vector2(9.0, -22.0), Vector2(-pull, 0), Color("#d9c8a5"), 1.0, true)
	draw_line(Vector2(-pull, 0), Vector2(9.0, 22.0), Color("#d9c8a5"), 1.0, true)
	draw_line(Vector2(-pull - 2.0, 0), Vector2(27.0, 0), Color("#ffc857"), 1.8, true)
	draw_colored_polygon(PackedVector2Array([Vector2(27, 0), Vector2(20, -3), Vector2(20, 3)]), Color("#ffc857"))
	if main and main.aiming and main.aim_power > 0.02:
		draw_circle(Vector2(27, 0), 4.0, Color(1.0, 0.72, 0.32, 0.18))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)

func _draw_enemies() -> void:
	for e in main.enemies:
		_draw_enemy(e)

func _draw_enemy(e: Dictionary) -> void:
	var x := float(e["x"])
	var h := float(e["height"])
	var state := str(e["state"])
	var alpha := 1.0
	var sink := 0.0
	if state == "dead":
		alpha = clampf(float(e["death_timer"]) / 0.68, 0.0, 1.0)
		sink = (1.0 - alpha) * 13.0
		if alpha <= 0.0:
			return
	var lunge := float(e["attack_anim"]) * 5.0
	var bob := sin(float(e["anim_time"]) * 7.0) * 1.7
	var ground := GameData.GROUND_Y + sink
	if state != "dead":
		_ellipse(Vector2(x, GameData.GROUND_Y), h * 0.32, h * 0.07, Color(0.02, 0.03, 0.07, 0.55 * alpha), 18)
	draw_set_transform(Vector2(x - lunge, ground + bob), 0.0, Vector2.ONE)
	var base := Color(str(e["color"]))
	var flash := float(e["hit_flash"])
	if flash > 0.0:
		base = base.lerp(Color(1, 1, 1, 1), clampf(flash * 0.8, 0.0, 0.8))
	base.a = alpha
	var dark := Color(base.r * 0.58, base.g * 0.55, base.b * 0.62, alpha)
	var light := Color(minf(1.0, base.r * 1.25), minf(1.0, base.g * 1.22), minf(1.0, base.b * 1.22), alpha)
	var kind := str(e["type"])
	var boss := bool(e.get("boss", false))
	var w := h * (0.50 if boss else (0.42 if kind == "brute" else 0.36))
	var head_y := -h * 0.88
	var head_r := h * (0.16 if boss else 0.145)
	var body_top := -h * 0.78
	var body_bottom := -h * 0.10
	# legs
	var swing := sin(float(e["anim_time"]) * 8.0) * 3.0
	draw_line(Vector2(-w * 0.36, body_bottom + 2), Vector2(-w * 0.48 + swing, -1), dark, maxf(3.0, h * 0.10), true)
	draw_line(Vector2(w * 0.32, body_bottom + 2), Vector2(w * 0.46 - swing, -1), dark, maxf(3.0, h * 0.10), true)
	draw_line(Vector2(-w * 0.60 + swing, 0), Vector2(-w * 0.30 + swing, 0), Color(dark.r * 0.7, dark.g * 0.7, dark.b * 0.7, alpha), maxf(2.0, h * 0.06), true)
	draw_line(Vector2(w * 0.30 - swing, 0), Vector2(w * 0.62 - swing, 0), Color(dark.r * 0.7, dark.g * 0.7, dark.b * 0.7, alpha), maxf(2.0, h * 0.06), true)
	# body
	draw_colored_polygon(PackedVector2Array([
		Vector2(-w, body_bottom), Vector2(-w * 0.92, body_top),
		Vector2(-w * 0.48, body_top - h * 0.05), Vector2(w * 0.48, body_top - h * 0.05),
		Vector2(w * 0.92, body_top), Vector2(w, body_bottom)
	]), base)
	draw_circle(Vector2(0, body_top + h * 0.03), w * 0.55, light)
	# belt
	draw_line(Vector2(-w * 0.85, body_bottom - h * 0.10), Vector2(w * 0.85, body_bottom - h * 0.10), dark, maxf(2.0, h * 0.05), true)
	# head
	draw_circle(Vector2(0, head_y), head_r, Color("#171322") if not boss else Color("#24151d"))
	# helmet / hood
	draw_colored_polygon(PackedVector2Array([
		Vector2(-head_r * 1.1, head_y - head_r * 0.1), Vector2(-head_r * 0.8, head_y - head_r * 1.1),
		Vector2(head_r * 0.85, head_y - head_r * 1.1), Vector2(head_r * 1.1, head_y - head_r * 0.1),
		Vector2(head_r * 0.7, head_y - head_r * 0.25), Vector2(-head_r * 0.7, head_y - head_r * 0.25)
	]), light)
	# eyes
	var eye_x := -head_r * 0.28
	draw_circle(Vector2(eye_x, head_y), 1.7, Color(1.0, 0.68, 0.30, 0.9 * alpha))
	draw_circle(Vector2(eye_x, head_y), 4.0, Color(1.0, 0.45, 0.15, 0.15 * alpha))
	if kind == "raider":
		_horns(head_y, head_r, Color("#bca985"), alpha)
		draw_line(Vector2(w * 0.7, body_top + h * 0.1), Vector2(-w * 0.62, body_top - h * 0.18), Color("#76502f"), maxf(2.5, h * 0.055), true)
		draw_colored_polygon(PackedVector2Array([
			Vector2(-w * 0.62, body_top - h * 0.18), Vector2(-w * 0.75, body_top - h * 0.25),
			Vector2(-w * 0.63, body_top - h * 0.11)
		]), Color("#c9b28f") if alpha > 0.2 else Color(0, 0, 0, 0))
	elif kind == "runner":
		draw_colored_polygon(PackedVector2Array([
			Vector2(-w * 0.2, body_top), Vector2(w * 0.3, body_top - h * 0.04),
			Vector2(w * 1.2 + sin(time * 8.0) * 6.0, body_top + h * 0.15),
			Vector2(-w * 0.1, body_top + h * 0.1)
		]), Color(0.55, 0.32, 0.26, alpha))
		draw_line(Vector2(-w * 0.75, body_top + h * 0.15), Vector2(-w * 1.1, body_top + h * 0.03), Color("#b9b6c9"), 2.0, true)
		draw_line(Vector2(-w * 0.72, body_top + h * 0.30), Vector2(-w * 1.0, body_top + h * 0.22), Color("#b9b6c9"), 2.0, true)
	elif kind == "shield":
		var shield_w := w * 0.95
		var shield_h := h * 0.62
		var shield_pos := Vector2(-w * 0.98, -h * 0.38)
		draw_colored_polygon(PackedVector2Array([
			shield_pos + Vector2(-shield_w * 0.55, -shield_h * 0.5),
			shield_pos + Vector2(shield_w * 0.15, -shield_h * 0.5),
			shield_pos + Vector2(shield_w * 0.5, -shield_h * 0.25),
			shield_pos + Vector2(shield_w * 0.35, shield_h * 0.45),
			shield_pos + Vector2(-shield_w * 0.3, shield_h * 0.5),
			shield_pos + Vector2(-shield_w * 0.55, shield_h * 0.2)
		]), Color("#344357"))
		draw_polyline(PackedVector2Array([
			shield_pos + Vector2(-shield_w * 0.55, -shield_h * 0.5),
			shield_pos + Vector2(shield_w * 0.15, -shield_h * 0.5),
			shield_pos + Vector2(shield_w * 0.5, -shield_h * 0.25),
			shield_pos + Vector2(shield_w * 0.35, shield_h * 0.45),
			shield_pos + Vector2(-shield_w * 0.3, shield_h * 0.5),
			shield_pos + Vector2(-shield_w * 0.55, shield_h * 0.2),
			shield_pos + Vector2(-shield_w * 0.55, -shield_h * 0.5)
		]), Color("#6c7f92"), 1.5, true)
		draw_circle(shield_pos + Vector2(-shield_w * 0.05, -shield_h * 0.02), h * 0.07, Color("#c9a76b"))
		_horns(head_y, head_r, Color("#aeb9c1"), alpha)
		draw_line(Vector2(-w * 0.2, body_top + h * 0.08), Vector2(w * 0.8, body_top + h * 0.2), Color("#2b3748"), 3.0, true)
		draw_colored_polygon(PackedVector2Array([
			Vector2(w * 0.8, body_top + h * 0.2), Vector2(w * 0.95, body_top + h * 0.12),
			Vector2(w * 0.92, body_top + h * 0.29)
		]), Color("#9ca8b2"))
	elif kind == "brute":
		draw_circle(Vector2(-w * 0.9, body_top + h * 0.04), w * 0.34, light)
		draw_circle(Vector2(w * 0.9, body_top + h * 0.04), w * 0.34, light)
		draw_colored_polygon(PackedVector2Array([
			Vector2(-w * 0.55, body_top + h * 0.15), Vector2(w * 0.55, body_top + h * 0.15),
			Vector2(w * 0.4, body_bottom), Vector2(-w * 0.4, body_bottom)
		]), Color(0.28, 0.16, 0.28, alpha))
		_horns(head_y, head_r * 1.1, Color("#d3bea0"), alpha)
		draw_line(Vector2(w * 0.9, body_top), Vector2(w * 1.45, body_top + h * 0.12), Color("#6b5438"), maxf(4.0, h * 0.08), true)
		draw_circle(Vector2(w * 1.45, body_top + h * 0.12), h * 0.10, Color("#3a2b24"))
		draw_circle(Vector2(w * 1.45, body_top + h * 0.12), h * 0.10 * 0.55, Color("#6b5438"))
	elif kind == "torch":
		var flame_h := h * 0.16 + sin(time * 13.0) * 2.0
		draw_colored_polygon(PackedVector2Array([
			Vector2(-head_r * 0.7, head_y - head_r * 0.6), Vector2(0, head_y - head_r - flame_h),
			Vector2(head_r * 0.7, head_y - head_r * 0.6)
		]), Color("#ff8a35"))
		draw_colored_polygon(PackedVector2Array([
			Vector2(-head_r * 0.3, head_y - head_r * 0.5), Vector2(0, head_y - head_r - flame_h * 0.55),
			Vector2(head_r * 0.3, head_y - head_r * 0.5)
		]), Color("#fff0b3"))
		draw_circle(Vector2(0, head_y - head_r), 18.0, Color(1.0, 0.48, 0.18, 0.06 * alpha))
		draw_line(Vector2(w * 0.3, body_top - h * 0.08), Vector2(w * 0.75, body_top + h * 0.20), Color("#5b4128"), 2.0, true)
	elif kind == "slinger":
		draw_colored_polygon(PackedVector2Array([
			Vector2(-w * 0.2, body_top), Vector2(w * 0.2, body_top - h * 0.10),
			Vector2(w * 0.8, body_top + h * 0.12), Vector2(-w * 0.3, body_top + h * 0.08)
		]), Color(0.18, 0.28, 0.23, alpha))
		draw_line(Vector2(-w * 0.4, body_top + h * 0.12), Vector2(-w * 1.1, body_top + h * 0.34), Color("#5b4128"), 2.5, true)
		draw_arc(Vector2(-w * 1.12, body_top + h * 0.37), 7.0, -2.4, 1.0, 8, Color("#b9a072"), 1.5, true)
		draw_line(Vector2(-w * 1.15, body_top + h * 0.30), Vector2(-w * 1.18, body_top + h * 0.46), Color("#b9a072"), 1.0, true)
	elif boss:
		draw_colored_polygon(PackedVector2Array([
			Vector2(-w * 0.6, body_top + h * 0.05), Vector2(w * 0.6, body_top + h * 0.05),
			Vector2(w * 1.2, body_bottom + h * 0.1), Vector2(-w * 1.05, body_bottom + h * 0.1)
		]), Color(0.28, 0.10, 0.15, alpha))
		_horns(head_y, head_r * 1.3, Color("#e4c58f"), alpha)
		draw_line(Vector2(w * 0.7, body_top + h * 0.1), Vector2(w * 1.25, body_top - h * 0.1), Color("#5a3e2e"), maxf(4.0, h * 0.07), true)
		draw_colored_polygon(PackedVector2Array([
			Vector2(w * 0.98, body_top - h * 0.16), Vector2(w * 1.45, body_top - h * 0.24),
			Vector2(w * 1.35, body_top + h * 0.02), Vector2(w * 1.02, body_top + h * 0.06)
		]), Color("#aeb9c1"))
		draw_circle(Vector2(0, body_top + h * 0.13), h * 0.075, Color(1.0, 0.55, 0.22, 0.75 * alpha))
		draw_circle(Vector2(0, body_top + h * 0.13), h * 0.13, Color(1.0, 0.35, 0.15, 0.12 * alpha))
	# health bar
	if state != "dead" and not boss and float(e["hp"]) < float(e["max_hp"]):
		var bar_w := h * 0.62
		var bar_y := head_y - head_r - 12.0
		draw_rect(Rect2(-bar_w * 0.5, bar_y, bar_w, 3.0), Color(0.02, 0.03, 0.06, 0.7))
		draw_rect(Rect2(-bar_w * 0.5, bar_y, bar_w * clampf(float(e["hp"]) / float(e["max_hp"]), 0.0, 1.0), 3.0), Color("#e5484d"))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)

func _horns(head_y: float, head_r: float, color: Color, alpha: float) -> void:
	draw_colored_polygon(PackedVector2Array([
		Vector2(-head_r * 0.95, head_y - head_r * 0.55), Vector2(-head_r * 1.35, head_y - head_r * 1.20),
		Vector2(-head_r * 0.45, head_y - head_r * 0.75)
	]), Color(color.r, color.g, color.b, alpha))
	draw_colored_polygon(PackedVector2Array([
		Vector2(head_r * 0.95, head_y - head_r * 0.55), Vector2(head_r * 1.35, head_y - head_r * 1.20),
		Vector2(head_r * 0.45, head_y - head_r * 0.75)
	]), Color(color.r, color.g, color.b, alpha))

func _draw_rocks() -> void:
	for r in main.rocks:
		if bool(r.get("dead", false)):
			continue
		var p: Vector2 = r["pos"]
		var spin := float(r["spin"])
		draw_circle(p, 7.0, Color(0.02, 0.02, 0.05, 0.25))
		draw_circle(p, 5.5, Color("#6b6259"))
		draw_circle(p + Vector2(1.5, -1.5), 3.8, Color("#84796c"))
		draw_line(p + Vector2(-5, 0), p + Vector2(-11, 2), Color(0.55, 0.44, 0.31, 0.30), 2.0)
		draw_line(p + Vector2(cos(spin) * 5, sin(spin) * 5), p + Vector2(cos(spin + 1.4) * 5, sin(spin + 1.4) * 5), Color(0.2, 0.16, 0.14, 0.8), 1.0)

func _draw_arrows() -> void:
	for a in main.arrows:
		var trail: Array = a["trail"]
		for i in range(1, trail.size()):
			var alpha := (1.0 - float(i) / float(trail.size())) * 0.30
			draw_line(trail[i - 1], trail[i], Color(1.0, 0.72, 0.32, alpha), 1.4)
		var p: Vector2 = a["pos"]
		var v: Vector2 = a["vel"]
		var dir := v.normalized()
		var tail := p - dir * 18.0
		draw_line(tail, p, Color("#f3ead9"), 1.5, true)
		draw_colored_polygon(PackedVector2Array([
			p + dir * 8.0, p + dir * -2.0 + Vector2(-dir.y, dir.x) * 3.0,
			p + dir * -2.0 - Vector2(-dir.y, dir.x) * 3.0
		]), Color("#ffc857"))
		draw_line(tail, tail - dir * 5.0 + Vector2(-dir.y, dir.x) * 3.0, Color("#b9b6c9"), 1.0, true)
		draw_line(tail, tail - dir * 5.0 - Vector2(-dir.y, dir.x) * 3.0, Color("#b9b6c9"), 1.0, true)
		draw_circle(p, 6.0, Color(1.0, 0.62, 0.24, 0.08))

func _draw_aim() -> void:
	if not main.aiming:
		return
	if main.aim_power <= 0.02:
		draw_circle(main.aim_current, 5.0, Color(1.0, 0.72, 0.32, 0.55))
		return
	var pts: Array = main.aim_preview
	var packed := PackedVector2Array()
	for p in pts:
		packed.append(p)
	if packed.size() > 1:
		draw_polyline(packed, Color(1.0, 0.72, 0.32, 0.16), 1.4, true)
	for i in range(0, pts.size(), 1):
		var t := float(i) / maxf(1.0, float(pts.size()))
		draw_circle(pts[i], 2.2 - t * 0.8, Color(1.0, 0.80, 0.38, 0.88 * (1.0 - t * 0.4)))
	if pts.size() > 0:
		var end: Vector2 = pts[pts.size() - 1]
		draw_circle(end, 14.0, Color(1.0, 0.70, 0.30, 0.07))
		draw_arc(end, 8.0, 0.0, TAU, 16, Color(1.0, 0.80, 0.42, 0.9), 1.3, true)
		draw_line(end + Vector2(-12, 0), end + Vector2(-4, 0), Color(1.0, 0.80, 0.42, 0.75), 1.0)
		draw_line(end + Vector2(4, 0), end + Vector2(12, 0), Color(1.0, 0.80, 0.42, 0.75), 1.0)
		draw_line(end + Vector2(0, -12), end + Vector2(0, -4), Color(1.0, 0.80, 0.42, 0.75), 1.0)
		draw_line(end + Vector2(0, 4), end + Vector2(0, 12), Color(1.0, 0.80, 0.42, 0.75), 1.0)
	# power meter above wall
	var mx := 16.0
	var my := 250.0
	draw_rect(Rect2(mx, my, 66.0, 6.0), Color(0.02, 0.03, 0.07, 0.6))
	draw_rect(Rect2(mx + 1.0, my + 1.0, 64.0 * main.aim_power, 4.0), Color("#ff7a2f"))
	draw_line(Vector2(mx, my - 2), Vector2(mx, my + 8), Color(0.95, 0.88, 0.75, 0.4), 1.0)
	draw_line(Vector2(mx + 33, my - 2), Vector2(mx + 33, my + 8), Color(0.95, 0.88, 0.75, 0.4), 1.0)
	draw_line(Vector2(mx + 66, my - 2), Vector2(mx + 66, my + 8), Color(0.95, 0.88, 0.75, 0.4), 1.0)

func _draw_effects() -> void:
	for e in main.effects:
		var t := clampf(float(e["life"]) / maxf(0.001, float(e.get("max_life", float(e["life"])))), 0.0, 1.0)
		var kind := str(e["kind"])
		var p: Vector2 = e["pos"]
		if kind == "spark":
			var col: Color = e["color"]
			draw_circle(p, float(e["size"]) * (0.4 + t * 0.9), Color(col.r, col.g, col.b, t))
			draw_circle(p, float(e["size"]) * 3.0, Color(col.r, col.g, col.b, t * 0.10))
		elif kind == "coin":
			draw_circle(p, 5.0, Color(1.0, 0.78, 0.34, t * 0.18))
			draw_circle(p, 3.1, Color(1.0, 0.82, 0.36, t))
			draw_circle(p + Vector2(-0.8, -0.8), 1.2, Color(1.0, 0.95, 0.76, t))
		elif kind == "text":
			var col: Color = e["color"]
			draw_string(font, p + Vector2(-45, 0), str(e["text"]), HORIZONTAL_ALIGNMENT_CENTER, 90.0, int(e["font_size"]), Color(col.r, col.g, col.b, t))
		elif kind == "ring":
			var radius: float = float(e["radius"]) * (1.0 - t) + 8.0
			draw_arc(p, radius, 0.0, TAU, 32, Color(Color(e["color"]).r, Color(e["color"]).g, Color(e["color"]).b, t * 0.65), 2.0, true)
		elif kind == "stuck":
			var ang := float(e.get("angle", -0.4))
			var tail := p - Vector2(cos(ang), sin(ang)) * 17.0
			draw_line(tail, p, Color(0.85, 0.80, 0.71, t * 0.9), 1.3, true)
			draw_line(tail, tail - Vector2(cos(ang), sin(ang)) * 4.0 + Vector2(-sin(ang), cos(ang)) * 2.5, Color(0.72, 0.70, 0.68, t * 0.8), 1.0, true)
			draw_line(tail, tail - Vector2(cos(ang), sin(ang)) * 4.0 - Vector2(-sin(ang), cos(ang)) * 2.5, Color(0.72, 0.70, 0.68, t * 0.8), 1.0, true)

func _draw_foreground() -> void:
	var base := GameData.GROUND_Y + 2.0
	for i in 10:
		var x := 170.0 + fposmod(sin(float(i) * 6.13) * 47.0, 1.0) * (vp.x - 180.0)
		var h := 5.0 + fposmod(sin(float(i) * 3.71) * 9.0, 1.0) * 7.0
		draw_line(Vector2(x, base), Vector2(x - 2.0, base - h), Color(0.06, 0.08, 0.15, 0.75), 1.2)
		draw_line(Vector2(x, base), Vector2(x + 3.0, base - h * 0.7), Color(0.06, 0.08, 0.15, 0.6), 1.0)

func _draw_ambient_embers() -> void:
	var count: int = 30 if (main and (main.state == 0 or main.state == 1)) else 20
	for i in count:
		var e: Dictionary = embers[i % embers.size()]
		var yy := 1.0 - fposmod(time * float(e["speed"]) + float(e["phase"]), 1.0)
		var x := float(e["x"]) * vp.x + sin(time * float(e["drift"]) + float(e["phase"]) * 9.0) * 18.0
		var y := stage_y + 20.0 + yy * (GameData.GROUND_Y - 20.0)
		var alpha := 0.22 + 0.55 * absf(sin(time * 1.7 + float(e["phase"]) * 8.0))
		draw_circle(Vector2(x, y), float(e["size"]), Color(1.0, 0.55, 0.22, alpha))
		draw_circle(Vector2(x, y), float(e["size"]) * 3.5, Color(1.0, 0.42, 0.15, alpha * 0.06))

func _ellipse(center: Vector2, rx: float, ry: float, color: Color, segments: int = 20) -> void:
	var pts := PackedVector2Array()
	for i in segments:
		var a := TAU * float(i) / float(segments)
		pts.append(center + Vector2(cos(a) * rx, sin(a) * ry))
	draw_colored_polygon(pts, color)
