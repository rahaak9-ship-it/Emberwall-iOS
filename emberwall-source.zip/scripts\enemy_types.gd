class_name EnemyTypes
extends RefCounted

const DATA := {
	"raider": {
		"hp": 34.0, "speed": 31.0, "damage": 6.0, "coins": 4, "score": 10,
		"height": 52.0, "armor": 0.0, "kind": "melee", "color": "#a64b3c"
	},
	"runner": {
		"hp": 22.0, "speed": 56.0, "damage": 4.0, "coins": 3, "score": 12,
		"height": 44.0, "armor": 0.0, "kind": "melee", "color": "#8c7a45"
	},
	"shield": {
		"hp": 64.0, "speed": 20.0, "damage": 8.0, "coins": 7, "score": 18,
		"height": 58.0, "armor": 0.45, "kind": "melee", "color": "#556b7c"
	},
	"brute": {
		"hp": 132.0, "speed": 15.0, "damage": 14.0, "coins": 12, "score": 30,
		"height": 78.0, "armor": 0.15, "kind": "melee", "color": "#6f3e5a"
	},
	"torch": {
		"hp": 27.0, "speed": 48.0, "damage": 18.0, "coins": 5, "score": 16,
		"height": 42.0, "armor": 0.0, "kind": "suicide", "color": "#b85a2e"
	},
	"slinger": {
		"hp": 44.0, "speed": 24.0, "damage": 0.0, "coins": 6, "score": 20,
		"height": 52.0, "armor": 0.0, "kind": "ranged", "color": "#4a6656",
		"range_ratio": 0.56
	},
	"boss": {
		"hp": 540.0, "speed": 12.0, "damage": 24.0, "coins": 80, "score": 150,
		"height": 108.0, "armor": 0.12, "kind": "melee", "color": "#7b2f3f",
		"boss": true
	}
}

static func get_stats(type: String, wave: int) -> Dictionary:
	var base: Dictionary = DATA.get(type, DATA["raider"]).duplicate(true)
	var hp_scale := 1.0 + maxf(0.0, float(wave - 1)) * 0.045
	var speed_scale := minf(1.10, 1.0 + maxf(0.0, float(wave - 1)) * 0.006)
	if type == "boss":
		hp_scale = 1.0 + maxf(0.0, float(wave - 12)) * 0.30
		base["hp"] = float(base["hp"]) * hp_scale
	else:
		base["hp"] = float(base["hp"]) * hp_scale
	base["speed"] = float(base["speed"]) * speed_scale
	base["max_hp"] = float(base["hp"])
	base["type"] = type
	return base
