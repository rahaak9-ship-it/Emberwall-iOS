class_name TutorialArt
extends Control

var mode := 0
var font: Font

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	font = ThemeDB.fallback_font

func _draw() -> void:
	var w := size.x
	var h := size.y
	var cx := w * 0.5
	var cy := h * 0.52
	draw_rect(Rect2(0, 0, w, h), Color(0.02, 0.035, 0.08, 0.38))
	draw_line(Vector2(20, h - 14), Vector2(w - 20, h - 14), Color(1.0, 0.78, 0.38, 0.13), 1.0)
	if mode == 0:
		_draw_bow_page(w, h)
	elif mode == 1:
		_draw_head_page(w, h)
	else:
		_draw_shop_page(w, h)

func _draw_bow_page(w: float, h: float) -> void:
	var bow := Vector2(w * 0.18, h * 0.52)
	draw_circle(bow + Vector2(0, 26), 26.0, Color(0.03, 0.05, 0.11, 0.4))
	draw_arc(bow, 25.0, -1.2, 1.2, 18, Color("#8b6741"), 3.0, true)
	draw_line(bow + Vector2(9, -23), bow + Vector2(-10, 2), Color("#d9c8a5"), 1.2, true)
	draw_line(bow + Vector2(-10, 2), bow + Vector2(9, 23), Color("#d9c8a5"), 1.2, true)
	draw_line(bow + Vector2(-10, 2), bow + Vector2(25, 2), Color("#ffc857"), 2.0, true)
	draw_colored_polygon(PackedVector2Array([
		bow + Vector2(25, 2), bow + Vector2(17, -2), bow + Vector2(17, 6)
	]), Color("#ffc857"))
	var pts := PackedVector2Array()
	for i in 18:
		var t := float(i) / 17.0
		var x := lerpf(bow.x + 50.0, w * 0.82, t)
		var y := bow.y - sin(t * PI) * h * 0.36
		pts.append(Vector2(x, y))
		if i % 2 == 0:
			draw_circle(Vector2(x, y), 1.8, Color(1.0, 0.80, 0.40, 0.65))
	var end := Vector2(w * 0.82, bow.y + 4)
	draw_arc(end, 9.0, 0.0, TAU, 18, Color(1.0, 0.80, 0.40, 0.7), 1.2, true)
	draw_line(Vector2(w * 0.5, h - 23), Vector2(w * 0.5 - 52, h - 23), Color(0.88, 0.84, 0.76, 0.35), 2.0)
	draw_colored_polygon(PackedVector2Array([
		Vector2(w * 0.5 - 62, h - 23), Vector2(w * 0.5 - 50, h - 29), Vector2(w * 0.5 - 50, h - 17)
	]), Color(1.0, 0.70, 0.30, 0.8))

func _draw_head_page(w: float, h: float) -> void:
	var head := Vector2(w * 0.5, h * 0.49)
	draw_circle(head, 26.0, Color("#271b20"))
	draw_circle(head + Vector2(0, 2), 21.0, Color("#52302e"))
	draw_colored_polygon(PackedVector2Array([
		head + Vector2(-25, -9), head + Vector2(-36, -27), head + Vector2(-12, -18)
	]), Color("#c9b28f"))
	draw_colored_polygon(PackedVector2Array([
		head + Vector2(25, -9), head + Vector2(36, -27), head + Vector2(12, -18)
	]), Color("#c9b28f"))
	draw_circle(head + Vector2(-8, 0), 2.3, Color(1.0, 0.65, 0.28))
	draw_arc(head, 38.0, 0.0, TAU, 32, Color(1.0, 0.80, 0.40, 0.65), 1.2, true)
	draw_line(head + Vector2(-56, 0), head + Vector2(-42, 0), Color(1.0, 0.80, 0.40, 0.75), 1.2)
	draw_line(head + Vector2(42, 0), head + Vector2(56, 0), Color(1.0, 0.80, 0.40, 0.75), 1.2)
	draw_line(head + Vector2(0, -56), head + Vector2(0, -42), Color(1.0, 0.80, 0.40, 0.75), 1.2)
	draw_line(head + Vector2(0, 42), head + Vector2(0, 56), Color(1.0, 0.80, 0.40, 0.75), 1.2)
	for i in 8:
		var a := TAU * float(i) / 8.0 + 0.2
		draw_line(head + Vector2(cos(a), sin(a)) * 30.0, head + Vector2(cos(a), sin(a)) * 36.0, Color(1.0, 0.80, 0.40, 0.45), 1.0)
	draw_string(font, head + Vector2(48, 8), "x2", HORIZONTAL_ALIGNMENT_LEFT, -1, 24, Color("#ffc857"))
	draw_string(font, head + Vector2(-40, 74), "HEADSHOT", HORIZONTAL_ALIGNMENT_LEFT, -1, 8, Color(1.0, 0.80, 0.40, 0.55))

func _draw_shop_page(w: float, h: float) -> void:
	var card_w := 80.0
	var gap := 12.0
	var start := (w - card_w * 3.0 - gap * 2.0) * 0.5
	for i in 3:
		var x := start + float(i) * (card_w + gap)
		var y := h * 0.22
		draw_rect(Rect2(x, y, card_w, 68), Color(0.06, 0.09, 0.18, 0.9))
		draw_rect(Rect2(x, y, card_w, 2), [Color("#ff7a2f"), Color("#ffc857"), Color("#55c7b4")][i])
		draw_circle(Vector2(x + card_w * 0.5, y + 28), 9.0, [Color("#ff7a2f"), Color("#ffc857"), Color("#55c7b4")][i] * Color(1, 1, 1, 0.22))
		draw_line(Vector2(x + 14, y + 54), Vector2(x + card_w - 14, y + 54), Color(1.0, 0.78, 0.38, 0.28), 2.0)
	var wall_x := w * 0.5 - 72.0
	var wall_y := h - 34.0
	draw_rect(Rect2(wall_x, wall_y, 144, 18), Color(0.14, 0.19, 0.32, 0.95))
	for i in 4:
		draw_rect(Rect2(wall_x + float(i) * 36.0, wall_y - 6.0, 24, 6), Color(0.16, 0.22, 0.37, 0.95))
	draw_rect(Rect2(wall_x, wall_y + 7, 144, 2), Color(0.31, 0.37, 0.54, 0.7))
	draw_circle(Vector2(w * 0.5, h * 0.58), 4.0, Color(0.33, 0.78, 0.70, 0.8))
	draw_arc(Vector2(w * 0.5, h * 0.58), 12.0, 0.0, TAU, 18, Color(0.33, 0.78, 0.70, 0.35), 1.0, true)
