extends SceneTree

func _init() -> void:
	var icon_svg := FileAccess.get_file_as_string("res://assets/branding/icon.svg")
	var splash_svg := FileAccess.get_file_as_string("res://assets/branding/splash.svg")
	var icon := Image.new()
	var err := icon.load_svg_from_string(icon_svg, 2.0)
	if err != OK:
		push_error("Icon SVG failed: %s" % err)
		quit(1)
		return
	icon.save_png("res://assets/branding/icon_1024.png")
	var icon512 := icon.duplicate() as Image
	icon512.resize(512, 512, Image.INTERPOLATE_LANCZOS)
	icon512.save_png("res://assets/branding/icon_512.png")
	var sizes := {
		"app_store_1024x1024.png": 1024,
		"ipad_167x167.png": 167,
		"ipad_152x152.png": 152,
		"iphone_180x180.png": 180,
		"iphone_120x120.png": 120,
		"ios_192x192.png": 192,
		"ios_136x136.png": 136,
		"ios_128x128.png": 128,
		"settings_87x87.png": 87,
		"settings_58x58.png": 58,
		"notification_76x76.png": 76,
		"notification_60x60.png": 60,
		"notification_114x114.png": 114,
		"notification_40x40.png": 40,
		"spotlight_120x120.png": 120,
		"spotlight_80x80.png": 80
	}
	var ios_dir := "res://assets/branding/ios"
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(ios_dir))
	for file_name in sizes:
		var img := icon.duplicate() as Image
		var px := int(sizes[file_name])
		img.resize(px, px, Image.INTERPOLATE_LANCZOS)
		img.save_png(ios_dir + "/" + file_name)
	var splash := Image.new()
	err = splash.load_svg_from_string(splash_svg, 1.0)
	if err != OK:
		push_error("Splash SVG failed: %s" % err)
		quit(1)
		return
	splash.save_png("res://assets/branding/splash.png")
	print("Branding rendered: 1024 icon, 512 icon, 15 iOS sizes, splash 1280x720")
	quit(0)
