extends SceneTree

var main: Node

func _init() -> void:
	call_deferred("_run")

func _run() -> void:
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path("res://previews"))
	DisplayServer.window_set_size(Vector2i(932, 430))
	await process_frame
	await process_frame

	main = load("res://scenes/main.tscn").instantiate()
	root.add_child(main)
	await process_frame
	main.language = "ar"
	main.save_data["language"] = "ar"
	main.ui.refresh_language()
	main.ui.show_menu()
	await process_frame
	await process_frame
	await process_frame

	await _shot("menu")

	# A staged gameplay tableau.
	main.set_process(false)
	main.wave = 4
	main.wave_elapsed = 10.0
	main.coins = 38
	main.score = 1240
	main.wall_hp = 68.0
	main.state = main.State.PLAYING
	main.spawn_queue = []
	main.spawned_count = 0
	main.enemies.clear()
	main.arrows.clear()
	main.effects.clear()
	main.rocks.clear()
	main.aiming = true
	main.aim_power = 0.72
	main.aim_dir = Vector2.from_angle(-0.57)
	main.aim_speed = 820.0
	main.aim_preview = main._simulate_aim(GameData.BOW_POS, main.aim_dir, main.aim_speed)
	var placements := [
		["torch", 618.0], ["raider", 708.0], ["shield", 806.0], ["brute", 900.0], ["slinger", 982.0]
	]
	for p in placements:
		main._spawn_enemy(str(p[0]))
		var e: Dictionary = main.enemies[main.enemies.size() - 1]
		e["x"] = float(p[1])
		e["attack_timer"] = 0.7
		e["anim_time"] = float(p[1]) * 0.03
	if main.enemies.size() > 1:
		var target: Dictionary = main.enemies[1]
		target["hp"] = 12.0
		main._add_effect_text(main._head_center(target) + Vector2(0, -10), "44", GameData.GOLD, 24, 0.9)
		main._add_effect_text(main._head_center(target) + Vector2(0, -30), "HEADSHOT", Color("#ffe3a0"), 9, 0.9)
		main._burst(main._head_center(target), Color("#ffc857"), 10, 100.0)
	main.arrows.append({
		"pos": Vector2(560, 330), "prev": Vector2(550, 332),
		"vel": Vector2(550, 110), "damage": 22.0, "hits_left": 1,
		"hits": [], "life": 0.4, "trail": [Vector2(536, 337), Vector2(548, 333), Vector2(560, 330)],
		"dead": false
	})
	main.ui.show_hud()
	main.ui.show_banner("الموجة 04", "حاملو النار", "NIGHT 04")
	await process_frame
	await process_frame
	await _shot("gameplay")

	# Shop.
	main.upgrades = {"damage": 2, "multishot": 0, "quickdraw": 1, "pierce": 0}
	main.repair_count = 1
	main.coins = 38
	main.state = main.State.SHOP
	main.wall_hp = 68.0
	main.ui.show_shop()
	await process_frame
	await process_frame
	await _shot("shop")

	# Tutorial.
	main.state = main.State.TUTORIAL
	main.tutorial_page = 0
	main.ui.show_tutorial()
	await process_frame
	await process_frame
	await _shot("tutorial")

	# Victory screen with dawn.
	main.state = main.State.VICTORY
	main.dawn = 1.0
	main.wave = 12
	main.kills = 87
	main.score = 4820
	main.high_score = 4820
	main.new_best = true
	main.ui.show_result(true)
	await process_frame
	await process_frame
	await _shot("victory")

	# Pause.
	main.state = main.State.PLAYING
	main.dawn = 0.0
	main.ui.show_hud()
	main.pause_game()
	await process_frame
	await process_frame
	await _shot("pause")

	print("PREVIEWS_DONE")
	quit(0)

func _shot(name: String) -> void:
	await process_frame
	await process_frame
	var img := root.get_texture().get_image()
	img.save_png("res://previews/%s.png" % name)
	print("SHOT %s %dx%d" % [name, img.get_width(), img.get_height()])
