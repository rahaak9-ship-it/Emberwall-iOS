class_name SaveGame
extends RefCounted

const DEFAULT_PATH := "user://emberwall.save"
static var path := DEFAULT_PATH

static func defaults() -> Dictionary:
	return {
		"version": 1,
		"high_score": 0,
		"best_wave": 1,
		"language": I18n.default_language(),
		"sound": true,
		"tutorial_seen": false
	}

static func load_game() -> Dictionary:
	var data := defaults()
	if not FileAccess.file_exists(path):
		return data
	var file := FileAccess.open(path, FileAccess.READ)
	if file == null:
		return data
	var text := file.get_as_text()
	file.close()
	var parsed: Variant = JSON.parse_string(text)
	if not parsed is Dictionary:
		return data
	var incoming: Dictionary = parsed
	data["high_score"] = maxi(0, int(incoming.get("high_score", 0)))
	data["best_wave"] = clampi(int(incoming.get("best_wave", 1)), 1, Levels.wave_count())
	var language := str(incoming.get("language", data["language"]))
	if language not in ["ar", "en"]:
		language = "en"
	data["language"] = language
	data["sound"] = bool(incoming.get("sound", true))
	data["tutorial_seen"] = bool(incoming.get("tutorial_seen", false))
	return data

static func store(data: Dictionary) -> void:
	var file := FileAccess.open(path, FileAccess.WRITE)
	if file == null:
		return
	file.store_string(JSON.stringify(data, "\t"))
	file.close()

static func reset_for_tests() -> void:
	path = DEFAULT_PATH + ".test"
	if FileAccess.file_exists(path):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(path))
