class_name Vignette
extends Control

var strength := 0.0
var low_health := 0.0
var time := 0.0

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_process(true)

func _process(delta: float) -> void:
	time += delta
	queue_redraw()

func _draw() -> void:
	var pulse := 0.65 + 0.35 * sin(time * 4.6)
	var s := clampf(strength, 0.0, 1.0) * 0.55 + clampf(low_health, 0.0, 1.0) * 0.16 * pulse
	if s <= 0.005:
		return
	var w := size.x
	var h := size.y
	for i in 8:
		var band := 6.0 + float(i) * 14.0
		var a := s * (0.11 - float(i) * 0.011)
		if a <= 0.0:
			continue
		draw_rect(Rect2(0, 0, w, band), Color(0.72, 0.10, 0.12, a))
		draw_rect(Rect2(0, h - band, w, band), Color(0.72, 0.10, 0.12, a))
		draw_rect(Rect2(0, 0, band, h), Color(0.72, 0.10, 0.12, a * 0.8))
		draw_rect(Rect2(w - band, 0, band, h), Color(0.72, 0.10, 0.12, a * 0.8))
