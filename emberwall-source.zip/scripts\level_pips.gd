class_name LevelPips
extends Control

var filled := 0
var maximum := 5
var accent := Color("#ffc857")

func _draw() -> void:
	var gap := 12.0
	var y := 1.0
	for i in maximum:
		var color := accent if i < filled else Color(0.88, 0.86, 0.79, 0.13)
		draw_rect(Rect2(float(i) * gap, y, 8.0, 4.0), color)
		if i < filled:
			draw_rect(Rect2(float(i) * gap - 1.0, y - 1.0, 10.0, 6.0), Color(accent.r, accent.g, accent.b, 0.10))
