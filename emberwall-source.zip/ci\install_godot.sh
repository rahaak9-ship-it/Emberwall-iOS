#!/usr/bin/env bash
# Installs the exact Godot editor and iOS export template used by the project.
set -euo pipefail

ROOT="${CM_BUILD_DIR:?CM_BUILD_DIR is required}"
TOOLS="$ROOT/ci-tools"
mkdir -p "$TOOLS"

GODOT_URL="https://github.com/godotengine/godot/releases/download/4.7.2-stable/Godot_v4.7.2-stable_macos.universal.zip"
TEMPLATES_URL="https://github.com/godotengine/godot/releases/download/4.7.2-stable/Godot_v4.7.2-stable_export_templates.tpz"

curl -fL --retry 3 -o "$TOOLS/godot.zip" "$GODOT_URL"
rm -rf "$TOOLS/godot"
mkdir -p "$TOOLS/godot"
unzip -q "$TOOLS/godot.zip" -d "$TOOLS/godot"

GODOT_BIN="$(find "$TOOLS/godot" -type f -path '*/Godot.app/Contents/MacOS/Godot' | head -n 1)"
test -n "$GODOT_BIN"
test -x "$GODOT_BIN"
echo "GODOT_BIN=$GODOT_BIN" >> "$CM_ENV"

curl -fL --retry 3 -o "$TOOLS/templates.tpz" "$TEMPLATES_URL"
TEMPLATE_DIR="$HOME/Library/Application Support/Godot/export_templates/4.7.2.stable"
mkdir -p "$TEMPLATE_DIR"
unzip -p "$TOOLS/templates.tpz" templates/ios.zip > "$TEMPLATE_DIR/ios.zip"
unzip -p "$TOOLS/templates.tpz" templates/version.txt > "$TEMPLATE_DIR/version.txt"
test -s "$TEMPLATE_DIR/ios.zip"
echo "iOS template:"
ls -lh "$TEMPLATE_DIR"
