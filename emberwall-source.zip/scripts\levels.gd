class_name Levels
extends RefCounted

const WAVES := [
	{
		"en": "FIRST NIGHT", "ar": "أول ليلة",
		"groups": [{"type": "raider", "count": 6, "gap": 1.05, "start": 1.7}]
	},
	{
		"en": "QUICK FEET", "ar": "أقدام سريعة",
		"groups": [
			{"type": "raider", "count": 7, "gap": 1.00, "start": 1.4},
			{"type": "runner", "count": 3, "gap": 0.75, "start": 6.0}
		]
	},
	{
		"en": "IRON LINE", "ar": "صف الحديد",
		"groups": [
			{"type": "raider", "count": 8, "gap": 0.95, "start": 1.2},
			{"type": "shield", "count": 2, "gap": 2.4, "start": 5.0}
		]
	},
	{
		"en": "FIREBEARERS", "ar": "حاملو النار",
		"groups": [
			{"type": "runner", "count": 6, "gap": 0.75, "start": 1.2},
			{"type": "torch", "count": 2, "gap": 2.0, "start": 5.5},
			{"type": "raider", "count": 4, "gap": 1.0, "start": 9.0}
		]
	},
	{
		"en": "THE BRUTE", "ar": "الوحش",
		"groups": [
			{"type": "raider", "count": 8, "gap": 0.90, "start": 1.2},
			{"type": "brute", "count": 1, "gap": 1.0, "start": 5.0},
			{"type": "shield", "count": 2, "gap": 2.0, "start": 8.0}
		]
	},
	{
		"en": "LONG SHADOWS", "ar": "ظلال طويلة",
		"groups": [
			{"type": "slinger", "count": 2, "gap": 3.0, "start": 2.0},
			{"type": "raider", "count": 8, "gap": 0.90, "start": 3.0},
			{"type": "runner", "count": 4, "gap": 0.70, "start": 9.0}
		]
	},
	{
		"en": "BREAKERS", "ar": "الكاسرون",
		"groups": [
			{"type": "runner", "count": 8, "gap": 0.65, "start": 1.2},
			{"type": "shield", "count": 3, "gap": 1.8, "start": 6.0},
			{"type": "torch", "count": 2, "gap": 1.4, "start": 10.0}
		]
	},
	{
		"en": "HAMMERFALL", "ar": "سقوط المطرقة",
		"groups": [
			{"type": "brute", "count": 2, "gap": 4.0, "start": 1.5},
			{"type": "raider", "count": 10, "gap": 0.80, "start": 4.0},
			{"type": "slinger", "count": 2, "gap": 2.5, "start": 8.0}
		]
	},
	{
		"en": "THE TIDE", "ar": "المد",
		"groups": [
			{"type": "shield", "count": 4, "gap": 1.6, "start": 1.2},
			{"type": "runner", "count": 8, "gap": 0.60, "start": 4.0},
			{"type": "torch", "count": 3, "gap": 1.2, "start": 8.5}
		]
	},
	{
		"en": "NO QUARTER", "ar": "لا رحمة",
		"groups": [
			{"type": "brute", "count": 2, "gap": 3.2, "start": 1.2},
			{"type": "slinger", "count": 3, "gap": 2.0, "start": 3.0},
			{"type": "shield", "count": 4, "gap": 1.4, "start": 6.0},
			{"type": "raider", "count": 10, "gap": 0.75, "start": 8.0}
		]
	},
	{
		"en": "LAST EMBERS", "ar": "آخر الجمر",
		"groups": [
			{"type": "torch", "count": 4, "gap": 1.0, "start": 1.0},
			{"type": "runner", "count": 10, "gap": 0.55, "start": 3.0},
			{"type": "shield", "count": 4, "gap": 1.3, "start": 7.0},
			{"type": "brute", "count": 2, "gap": 3.0, "start": 10.0}
		]
	},
	{
		"en": "THE WARLORD", "ar": "قائد الليل",
		"groups": [
			{"type": "boss", "count": 1, "gap": 1.0, "start": 2.0},
			{"type": "shield", "count": 4, "gap": 1.5, "start": 4.0},
			{"type": "raider", "count": 8, "gap": 0.85, "start": 7.0},
			{"type": "slinger", "count": 2, "gap": 2.0, "start": 10.0}
		]
	}
]

static func wave_count() -> int:
	return WAVES.size()

static func title(wave: int, language: String) -> String:
	var data: Dictionary = WAVES[clampi(wave - 1, 0, WAVES.size() - 1)]
	return str(data.get(language, data["en"]))

static func build(wave: int) -> Array:
	var index := clampi(wave - 1, 0, WAVES.size() - 1)
	var data: Dictionary = WAVES[index]
	var entries: Array = []
	for group in data["groups"]:
		var count := int(group["count"])
		for i in count:
			entries.append({
				"time": float(group["start"]) + float(i) * float(group["gap"]),
				"type": str(group["type"])
			})
	entries.sort_custom(func(a, b): return float(a["time"]) < float(b["time"]))
	return entries

static func wave_bonus(wave: int) -> int:
	return 15 + wave * 3

static func enemy_count(wave: int) -> int:
	var total := 0
	for entry in build(wave):
		total += 1
	return total
