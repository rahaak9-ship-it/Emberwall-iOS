extends SceneTree

var main: Node
var checks := 0
var failures := 0

func _init() -> void:
	call_deferred("_run")

func check(condition: bool, label: String) -> void:
	checks += 1
	if condition:
		print("PASS  ", label)
	else:
		failures += 1
		print("FAIL  ", label)

func close_enough(a: float, b: float, epsilon: float = 0.01) -> bool:
	return absf(a - b) <= epsilon

func _run() -> void:
	SaveGame.path = "user://emberwall.logic-test.save"
	if FileAccess.file_exists(SaveGame.path):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(SaveGame.path))

	# Data checks.
	check(Levels.wave_count() == 12, "campaign has 12 waves")
	var populated := true
	var total_entries := 0
	for w in range(1, 13):
		var entries := Levels.build(w)
		if entries.is_empty():
			populated = false
		var last_time := -1.0
		for entry in entries:
			if float(entry["time"]) < last_time:
				populated = false
			last_time = float(entry["time"])
		total_entries += entries.size()
	check(populated, "wave tables are populated and time-ordered")
	check(total_entries >= 90, "campaign has enough enemies for a full run")
	check(Levels.build(12).size() >= 15, "final wave has a real boss escort")
	check(Upgrades.cost("damage", 0) == 16, "first damage upgrade cost")
	check(Upgrades.cost("damage", 5) == 0, "maxed upgrade has no next cost")
	check(close_enough(Upgrades.damage_multiplier(5), 2.10), "damage multiplier caps at +110%")
	check(close_enough(Upgrades.cooldown_multiplier(4), 0.48), "quick draw reaches the cooldown floor")
	check(Upgrades.pierce_hits(2) == 3, "piercing tip hits three enemies")
	check(Upgrades.repair_cost(0) == 18 and Upgrades.repair_cost(3) == 36, "repair price scales")
	check(EnemyTypes.get_stats("boss", 12)["hp"] > EnemyTypes.get_stats("raider", 12)["hp"] * 5.0, "boss is a real boss")

	SaveGame.store({"version": 1, "high_score": 3210, "best_wave": 7, "language": "ar", "sound": false, "tutorial_seen": true})
	var loaded := SaveGame.load_game()
	check(int(loaded["high_score"]) == 3210 and int(loaded["best_wave"]) == 7, "save round-trips score and wave")
	check(str(loaded["language"]) == "ar" and bool(loaded["sound"]) == false, "save round-trips settings")
	check(bool(loaded["tutorial_seen"]), "save round-trips tutorial state")

	main = load("res://scenes/main.tscn").instantiate()
	root.add_child(main)
	await process_frame
	await process_frame
	check(main.ui != null and main.world != null, "main scene builds world and UI")
	check(main.state == main.State.MENU, "game boots to menu")
	check(main.wave == 1 and main.wall_hp == GameData.WALL_MAX, "menu starts from a clean wall")
	if main.audio:
		main.audio.set_enabled(false)
	main.set_process(false)

	main.start_run()
	await process_frame
	check(main.state == main.State.PLAYING, "run starts in playing state")
	check(main.wave == 1 and main.coins == GameData.START_COINS, "run starts with wave 1 and starting embers")
	check(main.spawn_queue.size() == 6, "wave 1 queues six raiders")
	check(main.ui.hud.visible, "HUD is visible during play")
	check(main.ui.hud.mouse_filter == Control.MOUSE_FILTER_IGNORE, "HUD lets battlefield touches through")

	# The headless input router does not inject screen touches, so call the same
	# unhandled-input entry point the viewport uses in a real window.
	main.aiming = false
	main.cooldown = 0.0
	var touch := InputEventScreenTouch.new()
	touch.index = 0
	touch.pressed = true
	touch.position = Vector2(500.0, 300.0)
	main._unhandled_input(touch)
	check(bool(main.aiming), "a screen touch reaches the aim controller through the HUD")
	var touch_up := InputEventScreenTouch.new()
	touch_up.index = 0
	touch_up.pressed = false
	touch_up.position = Vector2(500.0, 300.0)
	main._unhandled_input(touch_up)
	main.aiming = false
	main.cooldown = 0.0

	main.pause_game()
	check(main.state == main.State.PAUSED, "pause enters the paused state")
	main.resume_game()
	check(main.state == main.State.PLAYING, "resume returns to play")

	# Touch-style slingshot input.
	main.arrows.clear()
	main.effects.clear()
	main.cooldown = 0.0
	main._aim_begin(Vector2(500.0, 300.0))
	main._aim_update(Vector2(380.0, 365.0))
	check(main.aiming and float(main.aim_power) > 0.1, "slingshot drag builds aim power")
	main._aim_release(Vector2(380.0, 365.0))
	check(main.arrows.size() == 1, "releasing a drag fires an arrow")
	main.arrows.clear()
	main.effects.clear()
	main.aiming = false
	main.cooldown = 0.0

	# Spawn and aim a real arrow at a raider's head.
	main._spawn_enemy("raider")
	var enemy: Dictionary = main.enemies[0]
	enemy["x"] = 520.0
	enemy["state"] = "alive"
	var head: Vector2 = main._head_center(enemy)
	var flight := 0.72
	var dx: float = head.x - GameData.BOW_POS.x
	var dy: float = head.y - GameData.BOW_POS.y
	var velocity := Vector2(dx / flight, (dy - 0.5 * GameData.GRAVITY * flight * flight) / flight)
	main.aim_dir = velocity.normalized()
	main.aim_speed = velocity.length()
	main.aiming = true
	main.aim_power = 1.0
	main.cooldown = 0.0
	main._fire_arrow()
	check(main.arrows.size() == 1, "firing creates an arrow")
	for i in 90:
		main._update_arrows(1.0 / 60.0)
		if main.enemies.size() == 0 or str(main.enemies[0]["state"]) == "dead":
			break
	check(main.enemies.size() == 0 or str(main.enemies[0]["state"]) == "dead", "a real arrow can kill a raider")
	check(int(main.coins) > GameData.START_COINS, "kill awards embers")
	check(int(main.kills) == 1, "kill counter increments")
	main.aiming = false
	main.aim_preview.clear()

	# Aim preview shape.
	var preview: Array = main._simulate_aim(GameData.BOW_POS, Vector2.from_angle(-0.5), 700.0)
	check(preview.size() > 10, "aim preview has a ballistic path")
	check(Vector2(preview[0]).distance_to(GameData.BOW_POS) < 0.1, "aim preview starts at the bow")
	check(Vector2(preview[preview.size() - 1]).y <= GameData.GROUND_Y + 1.0, "aim preview ends at the ground")

	# Wall damage and defeat path.
	main.enemies.clear()
	main.arrows.clear()
	main.rocks.clear()
	main.wall_hp = 12.0
	main._damage_wall(5.0)
	check(close_enough(main.wall_hp, 7.0), "wall damage reduces integrity")
	main._damage_wall(20.0)
	check(main.wall_hp == 0.0 and main.defeat_timer > 0.0, "zero integrity starts the defeat sequence")
	main._finish_defeat()
	check(main.state == main.State.DEFEAT, "defeat reaches the result state")

	# Campaign flow, using real wave transitions and a shop purchase.
	main.start_run()
	main.coins = 500
	main.spawned_count = main.spawn_queue.size()
	main.enemies.clear()
	main._on_wave_cleared()
	check(main.shop_timer > 0.0, "wave clear schedules the shop")
	main._open_shop()
	check(main.state == main.State.SHOP, "shop opens after a wave")
	var damage_before := int(main.upgrades["damage"])
	main.buy_upgrade("damage")
	check(int(main.upgrades["damage"]) == damage_before + 1, "shop purchase raises an upgrade")
	main.wall_hp = 50.0
	var repair_uses := int(main.repair_count)
	main.repair_wall()
	check(main.wall_hp > 50.0 and int(main.repair_count) == repair_uses + 1, "shop repair restores wall integrity")
	main.next_wave()
	check(main.state == main.State.PLAYING and main.wave == 2, "next wave advances the campaign")

	# Walk the whole campaign through its real state transitions.
	for w in range(2, 13):
		if main.state != main.State.PLAYING:
			break
		main.spawned_count = main.spawn_queue.size()
		main.enemies.clear()
		main._on_wave_cleared()
		if w >= 12:
			check(main.victory_timer > 0.0, "final wave schedules victory")
			main._finish_victory()
		else:
			main._open_shop()
			if main.state != main.State.SHOP:
				break
			main.next_wave()
	check(main.state == main.State.VICTORY, "12 waves reach the victory state")
	check(main.score > 0, "campaign awards score")
	check(int(main.high_score) >= int(main.score), "victory records the high score")

	# JSON save path should now contain the campaign high score.
	SaveGame.load_game()
	var persisted := SaveGame.load_game()
	check(int(persisted["high_score"]) >= 1200, "campaign high score persists")

	main.queue_free()
	await process_frame
	if FileAccess.file_exists(SaveGame.path):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(SaveGame.path))

	# First-run path: Play opens the tutorial, and finishing it starts wave 1.
	SaveGame.path = "user://emberwall.first-run-test.save"
	if FileAccess.file_exists(SaveGame.path):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(SaveGame.path))
	var first: Node = load("res://scenes/main.tscn").instantiate()
	root.add_child(first)
	await process_frame
	await process_frame
	if first.audio:
		first.audio.set_enabled(false)
	first.set_process(false)
	check(first.state == first.State.MENU, "fresh install boots to menu")
	first.play_pressed()
	check(first.state == first.State.TUTORIAL and bool(first.tutorial_start_after), "first Play opens the tutorial")
	first.finish_tutorial()
	check(first.state == first.State.PLAYING and first.wave == 1, "finishing the tutorial starts wave 1")
	check(bool(first.save_data["tutorial_seen"]), "tutorial completion is saved")
	first.queue_free()
	await process_frame
	if FileAccess.file_exists(SaveGame.path):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(SaveGame.path))

	print("LOGIC_RESULT %d checks, %d failures" % [checks, failures])
	quit(0 if failures == 0 else 1)
