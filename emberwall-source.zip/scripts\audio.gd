class_name GameAudio
extends Node

const RATE := 22050
const POOL_SIZE := 10

var enabled := true
var streams: Dictionary = {}
var players: Array[AudioStreamPlayer] = []
var music_player: AudioStreamPlayer
var music_stream: AudioStreamWAV

func _ready() -> void:
	_build_streams()
	_build_music()
	_build_players()
	set_enabled(enabled)

func _build_players() -> void:
	for i in POOL_SIZE:
		var p := AudioStreamPlayer.new()
		p.bus = "Master"
		add_child(p)
		players.append(p)
	music_player = AudioStreamPlayer.new()
	music_player.bus = "Master"
	music_player.volume_db = -24.0
	add_child(music_player)
	music_player.stream = music_stream
	music_player.play()

func set_enabled(value: bool) -> void:
	enabled = value
	if not enabled:
		for p in players:
			p.stop()
		if music_player:
			music_player.stop()
	elif music_player and not music_player.playing:
		music_player.play()

func play_sfx(name: String, pitch: float = 1.0, volume_db: float = 0.0) -> void:
	if not enabled or not streams.has(name):
		return
	for p in players:
		if not p.playing:
			p.stream = streams[name]
			p.pitch_scale = clampf(pitch, 0.55, 1.7)
			p.volume_db = volume_db
			p.play()
			return
	var fallback: AudioStreamPlayer = players[0]
	fallback.stop()
	fallback.stream = streams[name]
	fallback.pitch_scale = clampf(pitch, 0.55, 1.7)
	fallback.volume_db = volume_db
	fallback.play()

func _build_streams() -> void:
	streams["bow"] = _encode(_synth_bow())
	streams["hit"] = _encode(_synth_hit())
	streams["headshot"] = _encode(_synth_headshot())
	streams["kill"] = _encode(_synth_kill())
	streams["coin"] = _encode(_synth_coin())
	streams["wall"] = _encode(_synth_wall())
	streams["explode"] = _encode(_synth_explode())
	streams["click"] = _encode(_synth_click())
	streams["horn"] = _encode(_synth_horn())
	streams["victory"] = _encode(_synth_victory())
	streams["defeat"] = _encode(_synth_defeat())

func _encode(samples: PackedFloat32Array) -> AudioStreamWAV:
	var bytes := PackedByteArray()
	bytes.resize(samples.size() * 2)
	for i in samples.size():
		var v := int(clampf(samples[i], -1.0, 1.0) * 32767.0)
		bytes.encode_s16(i * 2, v)
	var wav := AudioStreamWAV.new()
	wav.format = AudioStreamWAV.FORMAT_16_BITS
	wav.mix_rate = RATE
	wav.stereo = false
	wav.data = bytes
	return wav

func _buffer(duration: float) -> PackedFloat32Array:
	var buf := PackedFloat32Array()
	buf.resize(int(duration * RATE))
	return buf

func _synth_bow() -> PackedFloat32Array:
	var duration := 0.24
	var buf := _buffer(duration)
	var phase := 0.0
	var noise := 0.0
	for i in buf.size():
		var t := float(i) / RATE
		var f := lerpf(260.0, 92.0, t / duration)
		phase += TAU * f / RATE
		noise = lerpf(noise, randf_range(-1.0, 1.0), 0.22)
		var env := exp(-t * 13.0) * (1.0 - t / duration)
		buf[i] = (sin(phase) * 0.55 + noise * 0.14) * env * 0.8
	return buf

func _synth_hit() -> PackedFloat32Array:
	var duration := 0.14
	var buf := _buffer(duration)
	var phase := 0.0
	for i in buf.size():
		var t := float(i) / RATE
		var f := lerpf(135.0, 55.0, t / duration)
		phase += TAU * f / RATE
		var env := exp(-t * 26.0)
		buf[i] = (sin(phase) * 0.7 + randf_range(-1.0, 1.0) * 0.16) * env
	return buf

func _synth_headshot() -> PackedFloat32Array:
	var duration := 0.22
	var buf := _buffer(duration)
	for i in buf.size():
		var t := float(i) / RATE
		var env := exp(-t * 20.0)
		var p1 := sin(TAU * 1480.0 * t) * 0.32
		var p2 := sin(TAU * 2210.0 * t) * 0.18 * exp(-t * 8.0)
		var p3 := sin(TAU * 740.0 * t) * 0.22
		buf[i] = (p1 + p2 + p3) * env * 0.75
	return buf

func _synth_kill() -> PackedFloat32Array:
	var duration := 0.30
	var buf := _buffer(duration)
	var phase := 0.0
	for i in buf.size():
		var t := float(i) / RATE
		var f := lerpf(190.0, 48.0, minf(1.0, t / 0.18))
		phase += TAU * f / RATE
		var env := exp(-t * 9.0) * (1.0 - t / duration)
		buf[i] = (sin(phase) * 0.45 + sin(phase * 0.5) * 0.2 + randf_range(-1.0, 1.0) * 0.08) * env
	return buf

func _synth_coin() -> PackedFloat32Array:
	var duration := 0.20
	var buf := _buffer(duration)
	for i in buf.size():
		var t := float(i) / RATE
		var f := 880.0 if t < 0.075 else 1320.0
		var env := exp(-t * 13.0)
		buf[i] = (sin(TAU * f * t) * 0.32 + sin(TAU * f * 2.0 * t) * 0.1) * env
	return buf

func _synth_wall() -> PackedFloat32Array:
	var duration := 0.38
	var buf := _buffer(duration)
	var phase := 0.0
	var low := 0.0
	for i in buf.size():
		var t := float(i) / RATE
		var f := lerpf(78.0, 38.0, t / duration)
		phase += TAU * f / RATE
		low = lerpf(low, randf_range(-1.0, 1.0), 0.10)
		var env := exp(-t * 8.5) * (1.0 - t / duration)
		buf[i] = (sin(phase) * 0.55 + low * 0.35) * env
	return buf

func _synth_explode() -> PackedFloat32Array:
	var duration := 0.48
	var buf := _buffer(duration)
	var low := 0.0
	var phase := 0.0
	for i in buf.size():
		var t := float(i) / RATE
		low = lerpf(low, randf_range(-1.0, 1.0), 0.18)
		phase += TAU * lerpf(90.0, 32.0, t / duration) / RATE
		var env := exp(-t * 6.0) * (1.0 - t / duration)
		buf[i] = (low * 0.55 + sin(phase) * 0.35) * env
	return buf

func _synth_click() -> PackedFloat32Array:
	var duration := 0.06
	var buf := _buffer(duration)
	for i in buf.size():
		var t := float(i) / RATE
		buf[i] = sin(TAU * 760.0 * t) * exp(-t * 60.0) * 0.28
	return buf

func _synth_horn() -> PackedFloat32Array:
	var duration := 1.05
	var buf := _buffer(duration)
	for i in buf.size():
		var t := float(i) / RATE
		var env := minf(1.0, t / 0.09) * exp(-t * 1.8) * (1.0 - t / duration)
		var vibrato := 1.0 + sin(TAU * 4.5 * t) * 0.006
		var s := sin(TAU * 110.0 * vibrato * t) * 0.30
		s += sin(TAU * 165.0 * vibrato * t) * 0.18
		s += sin(TAU * 220.0 * t) * 0.08
		buf[i] = s * env
	return buf

func _synth_victory() -> PackedFloat32Array:
	var duration := 1.8
	var buf := _buffer(duration)
	var notes := [523.25, 659.25, 783.99, 1046.5]
	for i in buf.size():
		var t := float(i) / RATE
		var value := 0.0
		for n in notes.size():
			var start := n * 0.22
			if t >= start:
				var local := t - start
				var env := exp(-local * 4.0) * minf(1.0, local / 0.02)
				value += sin(TAU * notes[n] * local) * 0.16 * env
				value += sin(TAU * notes[n] * 2.0 * local) * 0.05 * env
		buf[i] = value
	return buf

func _synth_defeat() -> PackedFloat32Array:
	var duration := 1.5
	var buf := _buffer(duration)
	for i in buf.size():
		var t := float(i) / RATE
		var f := lerpf(220.0, 55.0, t / duration)
		var env := exp(-t * 1.4) * (1.0 - t / duration)
		buf[i] = (sin(TAU * f * t) * 0.35 + sin(TAU * f * 0.5 * t) * 0.18) * env
	return buf

func _build_music() -> void:
	var duration := 12.0
	var buf := _buffer(duration)
	var wind := 0.0
	var phase_a := 0.0
	var phase_b := 0.0
	var bell_times := [3.0, 8.4]
	for i in buf.size():
		var t := float(i) / RATE
		wind = lerpf(wind, randf_range(-1.0, 1.0), 0.0035)
		var wind_env := 0.55 + 0.45 * sin(TAU * 0.065 * t + 0.4)
		phase_a += TAU * 55.0 / RATE
		phase_b += TAU * 82.5 / RATE
		var drone := sin(phase_a) * 0.038 + sin(phase_b) * 0.016
		drone *= 0.75 + 0.25 * sin(TAU * 0.05 * t)
		var value := wind * 0.055 * wind_env + drone
		for bt in bell_times:
			var local := t - float(bt)
			if local >= 0.0 and local < 4.0:
				value += sin(TAU * 392.0 * local) * exp(-local * 1.15) * 0.018
		var fade := minf(1.0, t / 0.5) * minf(1.0, (duration - t) / 0.5)
		buf[i] = clampf(value * fade, -0.5, 0.5)
	var bytes := PackedByteArray()
	bytes.resize(buf.size() * 2)
	for i in buf.size():
		bytes.encode_s16(i * 2, int(clampf(buf[i], -1.0, 1.0) * 32767.0))
	music_stream = AudioStreamWAV.new()
	music_stream.format = AudioStreamWAV.FORMAT_16_BITS
	music_stream.mix_rate = RATE
	music_stream.stereo = false
	music_stream.data = bytes
	music_stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
	music_stream.loop_begin = 0
	music_stream.loop_end = buf.size()
