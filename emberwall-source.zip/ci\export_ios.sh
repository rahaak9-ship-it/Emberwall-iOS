#!/usr/bin/env bash
# Exports the Godot project into a native Xcode project.
set -euo pipefail

ROOT="${CM_BUILD_DIR:?CM_BUILD_DIR is required}"
cd "$ROOT"
test -n "${GODOT_BIN:-}"
test -n "${APPLE_TEAM_ID:-}"
test -n "${EMBERWALL_BUNDLE_ID:-}"

# Keep the preset in sync with the owner's Apple team and the new app identity.
sed -i '' "s#application/app_store_team_id=.*#application/app_store_team_id=\"${APPLE_TEAM_ID}\"#" export_presets.cfg
sed -i '' "s#application/bundle_identifier=.*#application/bundle_identifier=\"${EMBERWALL_BUNDLE_ID}\"#" export_presets.cfg
sed -i '' "s#export_path=.*#export_path=\"build/ios/Emberwall\"#" export_presets.cfg
grep -E 'app_store_team_id|bundle_identifier|export_path' export_presets.cfg

mkdir -p build/ios
"$GODOT_BIN" --headless --path "$ROOT" --export-debug "iOS" "build/ios/Emberwall" 2>&1 | tee build/godot-export.log
test -d build/ios/Emberwall.xcodeproj
test -f build/ios/Emberwall.pck
